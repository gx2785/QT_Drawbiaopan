#include "Dial.h"

Dial:: Dial(QWidget *parent , QString labelText, QString valueText,  QString iconFile ):
    QWidget(parent),
    label(labelText),
    Value_Text(valueText),
    iconfile(iconFile),
    icon(iconFile),
    timer_msec(0)
{

     Scale_decimal=1;                   //���ñ���С����
     center_decimal=1;


     if(!Value_Text.contains("%1"))
     {
         Value_Text = "%1";
     }

     radius=0;                          //�Ǳ�������Ȧ�뾶

     minvalue=0;
     maxvalue=120;                     //���̶̿����ֵ
     value=20;                         //��ǰֵ
     endvalue=0;


     modeColor=ModeSingleColor;

     ScaleColor=QColor(185,185,185);            //���̶̿���ɫ
     PointerColor=QColor(249,2,1);              //ָ����ɫ
     SingleSlideColor =QColor(83,213,251);      //�����ĵ���ɫ
     slideScaleColor = QColor(255,255,255);     //�����Ŀ̶���ɫ

     ValueColor=QColor(255,255,255);            //ֵ��ɫ(������ǩ)
     LabelColor=QColor(192,192,192);


     obkColor=QColor(252,252,248);               //��Բ����ɫ

     bkColor=QColor(26,26,26);                   //�ڶ���Բ����ɫ

     centercolor=QColor(38,38,38);                //����Բ�̱���ɫ


     connect(&timer,SIGNAL(timeout()),this,SLOT(ontimeout()));

}
void Dial::drawObkColor(QPainter& paint)      //������Բ
{
        paint.save();

        QConicalGradient  Conical(0,0,90);


        Conical.setColorAt(0,obkColor);
        Conical.setColorAt(0.5,obkColor);

        Conical.setColorAt(0.12,obkColor.darker(40));
        Conical.setColorAt(0.88,obkColor.darker(40));

        Conical.setColorAt(0.4,obkColor.darker(30));
        Conical.setColorAt(0.6,obkColor.darker(30));


        Conical.setColorAt(0.25,obkColor.darker(160));

        Conical.setColorAt(0.75,obkColor.darker(160));
        Conical.setColorAt(1,obkColor);
        paint.setBrush(Conical);
        paint.drawEllipse(QPointF(0,0), radius*0.96,radius*0.98);

        Conical.setAngle(270);

        Conical.setColorAt(0,obkColor.darker(40));
        Conical.setColorAt(0.5,obkColor.darker(40));

        Conical.setColorAt(0.25,obkColor.darker(160));

        Conical.setColorAt(0.75,obkColor.darker(160));

        paint.setBrush(Conical);
        paint.drawEllipse(QPointF(0,0), radius*0.93,radius*0.94);

        paint.restore();
}
void Dial::drawScalebkColor(QPainter &paint)        //���ƿ̶�Բ
{
    paint.save();

    paint.setBrush(bkColor);
    paint.drawEllipse(QPointF(0,0), radius*0.90,radius*0.90);

    paint.restore();
}

void Dial::drawbkColor(QPainter &paint)       //������Բ
{
    paint.save();


    paint.setBrush(bkColor);
    paint.drawEllipse(QPointF(0,0), radius*0.77-2,radius*0.77-2);

    paint.setBrush(bkColor.darker(200));

    QRadialGradient Radial(0,0,centerR*1.06,0,0);

    Radial.setColorAt(1,bkColor);
    Radial.setColorAt(0.98,bkColor.darker(110));
    Radial.setColorAt(0.95,bkColor.darker(120));
    Radial.setColorAt(0.90,bkColor.darker(130));

    paint.setBrush(Radial);

    paint.drawEllipse(QPointF(0,0),centerR*1.18,centerR*1.18);

    paint.restore();
}


void Dial::drawCenterColor(QPainter &paint)      //��������Բ
{
    paint.save();

    QRadialGradient Radial(0,0,centerR,0,0);

    Radial.setColorAt(1,centercolor.lighter(170));
    Radial.setColorAt(0.98,centercolor.lighter(150));
    Radial.setColorAt(0.95,centercolor.lighter(130));
    Radial.setColorAt(0.70,centercolor);

    paint.setBrush(Radial);
    paint.drawEllipse(QPointF(0,0), centerR,centerR);

    paint.restore();

}

void Dial::drawScaleColor(QPainter &paint)   //���ƿ̶�
{
    #define  SmallTop        3
    #define  SmallBottom     2

    #define  BigTop          5
    #define  BigBottom       3

    const QPointF smallPoint[4] = {
        QPointF( - SmallTop / 2, radius*0.90),
        QPointF( SmallTop / 2, radius*0.90),
        QPointF(SmallBottom / 2, radius*0.81),
        QPointF(-SmallBottom / 2, radius*0.81)
    };


    const QPointF BigPoint[4] = {
        QPointF(- BigTop / 2, radius*0.90),
        QPointF(BigTop / 2, radius*0.90),
        QPointF(BigBottom / 2, radius*0.77),
        QPointF(-BigBottom / 2, radius*0.77)
    };




    paint.save();

    paint.rotate(60);



    for (int scale = 0; scale <= 24; ++scale)
    {
        qreal Current_Value =(qreal)scale*((maxvalue-minvalue)/24);

        if((Current_Value>(value-minvalue)&&(paint.brush().color()!=ScaleColor)))
        {
            paint.setBrush(ScaleColor);

        }
        else if((Current_Value<=(value-minvalue)&&(paint.brush().color()!=slideScaleColor)))
        {
            paint.setBrush(slideScaleColor);
        }

      if(scale%4==0)
      {
       paint.drawConvexPolygon(BigPoint, 4);
      }
      else
        paint.drawConvexPolygon(smallPoint, 4);

      paint.rotate(10);
    }

     paint.restore();



}

void Dial::drawScaleTextColor(QPainter &paint)    //���ƿ̶�ֵ
{

    int alingns[7]={

        Qt::AlignVCenter|Qt::AlignLeft,
        Qt::AlignLeft|Qt::AlignHCenter,
        Qt::AlignLeft|Qt::AlignTop,
        Qt::AlignTop|Qt::AlignHCenter,
        Qt::AlignRight|Qt::AlignTop,
        Qt::AlignRight|Qt::AlignHCenter,
        Qt::AlignBottom|Qt::AlignRight
    };
        QPoint offest[7]={        /*У������λ��*/
            QPoint(1,-3),
            QPoint(-4,0),
            QPoint(0,8),
            QPoint(0,0),
            QPoint(-3,8),
            QPoint(-3,0),
            QPoint(-3,0)
         };

    int size;           //��̬�������ִ�С

    if(radius<=120)
        size = 10;
    else if((radius>120)&&(radius<500))
        size = 13+(radius-120)/30;
    else if(radius>=500)
        size = 13+(radius-120)/40;

    if((maxvalue-minvalue)>500)
    {
       qreal ratio= (maxvalue-minvalue)/5000.0;

       size = size/(1+ratio*0.1 +0.1);
    }

        paint.save();

        paint.setPen(ScaleColor);
        QString text("%1");
        paint.setFont(QFont("Euphemia",size,QFont::DemiBold));
        QPoint TextPoint(0,radius*0.77);
        TextPoint = CustomRotate(TextPoint,90,240);
        qreal TextRotate=210;

         for(int i=0;i<7;i++)              //����7����
        {

          qreal Current_Value =(qreal)i*((maxvalue-minvalue)/6)+minvalue;




          if((Current_Value>(value)&&(paint.pen().color()!=ScaleColor)))
          {
              paint.setPen(ScaleColor);

          }
          else if((Current_Value<=(value)&&(paint.pen().color()!=slideScaleColor)))
          {
              paint.setPen(slideScaleColor);
          }

           QString values= fetchDecimalPoint(text.arg(Current_Value),Scale_decimal);

           qreal xoffset;


           xoffset = (qreal)values.length()*size/2.0;



           if(alingns[i]&Qt::AlignLeft)     //����
           {

               paint.drawText(QRect(TextPoint.x()+offest[i].x(),TextPoint.y()-size+offest[i].y(),xoffset*2,size*2),alingns[i],values);

           }

           else if(alingns[i]&Qt::AlignRight)     //����
           {

               paint.drawText(QRect(TextPoint.x()-xoffset*2+offest[i].x(),TextPoint.y()-size+offest[i].y(),xoffset*2,size*2),alingns[i],values);

           }
           else         //����
           {

               paint.drawText(QRect(TextPoint.x()-xoffset+offest[i].x(),TextPoint.y()+offest[i].y(),xoffset*2,size*2),alingns[i],values);

           }


           TextPoint = CustomRotate(TextPoint,TextRotate,40);

           TextRotate-=40;
        }


        paint.restore();

}


void Dial::drawShade(QPainter &paint)              //������Ӱ
{

    paint.save();

    int PenWidth = radius*0.90-radius*0.77+4;


    paint.setPen(QPen(QBrush(QColor(255,255,255,30)),PenWidth));
    paint.setBrush(Qt::transparent);


    paint.drawArc(QRectF(-radius*0.90+PenWidth/2-3,-radius*0.90+PenWidth/2-3,radius*1.80-PenWidth+6,radius*1.80-PenWidth+6),-30*16+5*15,240*16-10*15);
    paint.restore();
}


void Dial::drawslideScaleColor(QPainter &paint)    //����������ɫ
{
    if(modeColor == ModeSingleColor)
    {
        drawslideScaleSingleColor(paint);
    }
    else
    {
        drawslideScaleGradientColor(paint);
    }

}


void Dial::drawslideScaleSingleColor(QPainter &paint)      //���ƻ����ĵ�ɫ
{

    int Star_Angle= 210*16-(int)(((value-minvalue)/(maxvalue-minvalue))*240*16);

    int spanAngle  =  210*16 - Star_Angle;


    if(spanAngle==0)
        return ;



    qreal SlideBottom =  ((qreal)radius*0.77)/((qreal)radius*0.90);

    qreal SlideCenterTop = 1-(1-SlideBottom)/3;
    qreal SlideCenterBottom = SlideBottom+(1-SlideBottom)/3+0.01;

    paint.save();

    QColor Tint_SlideColor = SingleSlideColor;


    QRadialGradient Radial(0,0,radius*0.90);


    Tint_SlideColor.setAlpha(40);
    Radial.setColorAt(1,Tint_SlideColor);
    Radial.setColorAt(SlideBottom-0.005,Tint_SlideColor);
    Radial.setColorAt(0,Qt::transparent);
    Radial.setColorAt(SlideBottom-0.006,Qt::transparent);


    Tint_SlideColor = SingleSlideColor;
    Tint_SlideColor.setAlpha(50);


    Radial.setColorAt(SlideCenterBottom-0.03,Tint_SlideColor);
    Radial.setColorAt(SlideCenterTop+0.03,Tint_SlideColor);

    Tint_SlideColor = SingleSlideColor;
    Tint_SlideColor.setAlpha(50);
    Radial.setColorAt(SlideCenterBottom-0.01,SingleSlideColor.darker(200));
    Radial.setColorAt(SlideCenterTop+0.01,SingleSlideColor.darker(200));

    Radial.setColorAt(SlideCenterBottom,SingleSlideColor);
    Radial.setColorAt(SlideCenterTop,SingleSlideColor);

    paint.setPen(Qt::NoPen);
    paint.setBrush(Radial);

    paint.drawPie(QRectF((qreal)-radius*0.90,(qreal)-radius*0.90,(qreal)radius*1.80,(qreal)radius*1.80),Star_Angle,spanAngle);

    paint.restore();

}




void Dial::drawslideScaleGradientColor(QPainter &paint)     //���ƻ����Ľ���ɫ
{

	int iColorSize = GradientSlideColor.count();
    qreal * pAngles= new qreal[iColorSize];

    qreal top=0.8666668;
    qreal bottom=0.8223336;


    int Star_Angle= 210*16-(int)(((value-minvalue)/(maxvalue-minvalue))*240*16);

    int spanAngle  =  210*16 - Star_Angle;



    if(spanAngle==0)
        return ;


    for(int i=0;i<GradientSlideColor.count();i++)
    {
        pAngles[GradientSlideColor.count()-i-1] =(qreal)(240/360.0)*(qreal) i/ (qreal)(GradientSlideColor.count()-1);

    }


    paint.save();

    QConicalGradient Conical(0,0,-30);

    /*���ƽ���*/
    for(int i =0 ; i<GradientSlideColor.count(); i++)
         Conical.setColorAt(pAngles[i],GradientSlideColor[i]);

    Conical.setColorAt(pAngles[0]+0.01,Qt::transparent);
    Conical.setColorAt(1,Qt::transparent);

    paint.setPen(Qt::NoPen);
    paint.setBrush(Conical);

    paint.drawPie(QRectF((qreal)-radius*top,(qreal)-radius*top,(qreal)radius*top*2,(qreal)radius*top*2),Star_Angle,spanAngle);



    paint.setBrush(bkColor);
    paint.drawPie(QRectF((qreal)-radius*bottom,(qreal)-radius*bottom,(qreal)radius*bottom*2,(qreal)radius*bottom*2),Star_Angle,spanAngle);

    QList<QColor> Tint_Colors = GradientSlideColor;

    for(int i=0; i< GradientSlideColor.count();i++)
       Tint_Colors[i].setAlpha(90);

    for(int i =0 ; i<GradientSlideColor.count(); i++)
         Conical.setColorAt(pAngles[i],Tint_Colors[i]);


    paint.setBrush(Conical);
    paint.drawPie(QRectF((qreal)-radius*0.90,(qreal)-radius*0.90,(qreal)radius*1.80,(qreal)radius*1.80),Star_Angle,spanAngle);


    paint.restore();

	delete [] pAngles;
	pAngles = NULL;

}


void Dial::drawPointColor(QPainter &paint)          //����ָ��
{

    qreal PointTop;                //��̬����ָ��ͷ
    qreal PointBottom;             //��̬����ָ��ײ�
    if(radius<=120)
    {
        PointTop = 2;
        PointBottom = 6;
    }
    else if((radius>120)&&(radius<500))
    {
        PointTop = 2 + (radius-120)/100;
        PointBottom = PointTop*3;
    }
    else if(radius>=500)
    {
        PointTop = 2 + (radius-120)/140;
        PointBottom = PointTop*3;
    }

    const QPointF  Pointer[4] = {
        QPointF(- PointTop / 2, radius*0.80),
        QPointF(PointTop / 2, radius*0.80),
        QPointF(PointBottom / 2, centerR*0.9),
        QPointF(-PointBottom / 2, centerR*0.9)
    };

    paint.save();


    paint.setBrush(PointerColor);
    paint.setPen(PointerColor.darker(150));


    qreal Current_Angle =60+(int)(((value-minvalue)/(maxvalue-minvalue))*240);

    paint.rotate(Current_Angle);

    paint.drawConvexPolygon(Pointer, 4);

    paint.restore();

}
void Dial::drawIconValueColor(QPainter &paint)           //����ͼ���value
{
    qreal IconSize;        // ͼ���С
    qreal ValueSize;        // Value��С


    paint.save();

    if(!icon.isNull())
    {

        IconSize =  radius/5;

        icon.load(iconfile);        //����װ��,��֤ͼƬ������

        icon = icon.scaled(IconSize,IconSize,Qt::KeepAspectRatio);

        paint.drawPixmap(-IconSize/2,-centerR*0.80,IconSize,IconSize,icon);
    }




    QString text("%1");


    QString text1= fetchDecimalPoint(text.arg(minvalue),center_decimal);
    QString text2= fetchDecimalPoint(text.arg(maxvalue),center_decimal);

    int size = qMax(text1.length(),text2.length());

    ValueSize = (qreal)(centerR*2)/(size+center_decimal);


    text= fetchDecimalPoint(text.arg(value),center_decimal);

    paint.setFont(QFont("DokChampa",ValueSize));
    paint.setPen(ValueColor);

    paint.drawText(QRectF(-centerR,-centerR*0.2,centerR*2,ValueSize*2),Qt::AlignCenter,Value_Text.arg(text)) ;

    paint.restore();
}

void Dial::drawlabelColor(QPainter &paint)           //���Ʊ�ǩ �������: km/h  kg/m3�ȵ�
{

    qreal ValueSize=centerR/5;

    paint.save();

    paint.setFont(QFont("Euphemia",ValueSize,QFont::DemiBold));
    paint.setPen(LabelColor);

    paint.drawText(QRectF(-ValueSize*6,centerR*1.2,ValueSize*12,ValueSize*2),Qt::AlignCenter,label) ;

    paint.restore();
}


void Dial::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    painter.setPen(Qt::NoPen);

    painter.setRenderHint(QPainter::Antialiasing,true);
    painter.setRenderHint(QPainter::SmoothPixmapTransform);

    painter.translate(width()/2,height()/2);

    radius = qMin(width(),height())/2;

    centerR=radius*0.4;       //��������Բ��С


    drawObkColor(painter);           //��Բ��

    drawScalebkColor(painter);      //���̶�Բ

    drawslideScaleColor(painter);   //����������ɫ

    drawShade(painter);            //����Ӱ

    drawScaleColor(painter);

    drawbkColor(painter);          //����Բ

    drawScaleTextColor(painter);   //���̶�ֵ


    drawPointColor(painter);
    drawCenterColor(painter);      //��������Բ
    drawIconValueColor(painter);
    drawlabelColor(painter);

}



/*  point: �������ڵĵ�
 *  from_angle : �������ڵĶ���
 *  rotate : ��Ҫ��ת�ĽǶ�,ֵΪ-360~360(Ϊ������ʾ��ʱ����ת,Ϊ������ʾ˳ʱ����ת)
 */

QPoint Dial::CustomRotate(QPointF point,qreal from_angle,qreal rotate)
{
    qreal PI=3.141592653589;
    QPointF Tmp;
    qreal arc = (rotate-from_angle)/180*PI;
    qreal Length = qSqrt(point.x()*point.x() +point.y()*point.y());

    Tmp.setX(Length*qCos(arc));
    Tmp.setY(Length*qSin(arc));

    return Tmp.toPoint();
}

//ͨ����������,����ȡҪ��������,����:����Ϊ12.234,����decimal_point=1,���Է���ֵΪ12.3
QString Dial::fetchDecimalPoint(QString value,int point)    //value:ֵ  point:Ҫ������С��λ
{
    int  pos= value.indexOf(".");

    if(pos==-1)
       return value;

    pos +=point;

    if(point==0)        //ȥ��С����
     pos -=1;

    if(pos>=value.length())
        return value;

    return value.left(pos+1);
}



void Dial::ontimeout()
{
    if(value!=endvalue)
    {
         bool isTop=endvalue>value? true:false;

        if(timer_value==0)
        {
            value = endvalue;
            send(isTop);
        }
        else if( qAbs(value-endvalue)<=qAbs(timer_value))
        {
             value = endvalue;
             send(isTop);
        }
        else if(value>endvalue)
        {
             value -=qAbs(timer_value);
        }
        else
        {
             value +=qAbs(timer_value);
        }

        update();
    }

    if(value==endvalue)
    {
      timer.stop();
    }
}


void Dial::setGradientColorMode(QList<QColor>& Qcolors)       //���ӽ���
{

        GradientSlideColor.clear();
        GradientSlideColor=Qcolors;

        modeColor = ModeGradientColor;

        update();
}
void Dial::setSingleColorMode(QColor color)
{
     modeColor = ModeSingleColor;
     update();
}

void Dial::set_Scale_decimal(int point)           //���ÿ̶�ֵ����С������λ
{
    Scale_decimal = point;
    update();

}
void Dial::set_Center_decimal(int point)           //����������ֵ����С������λ
{
    center_decimal = point;
    update();

}

void Dial::setTimerType(int msec,int v)   //���ö�ʱ������,ÿ������ms,�ܶ���ֵ
{
    timer_value = v;
    timer_msec  = msec;
    if(timer_msec)
    {
        timer.setInterval(timer_msec);

    }
    else if(timer_msec==0)
    {
        timer.stop();
    }
}

qreal Dial::EndValue()                    //��ȡ�յ�ֵ
{
     return endvalue;
}
qreal Dial::CurrentValue()                //��ȡ��ǰֵ
{
     return value;
}
qreal Dial::MinValue()                    //��ȡ��Сֵ
{
     return minvalue;
}
qreal Dial::MaxValue()                    //��ȡ���ֵ
{
     return maxvalue;
}


bool Dial::setCurrentValue(qreal v)      //���õ�ǰֵ(ͬʱҲ�Ὣ�յ�ֵ��Ϊһ��)
{
    if((v<minvalue)||(v>maxvalue))
    {
        return false;
    }

    value =  v;
    endvalue = v;

    update();

    return true;
}

bool Dial::setEndValue(qreal v)           //�����յ�ֵ
{

    if((v<minvalue)||(v>maxvalue))
    {
        return false;
    }

    endvalue = v;

    if(timer_msec==0)           //��ʾ��ʱ������Ҫ��ʱ,ֱ�������յ�
    {
      bool isTop=endvalue>value? true:false;

      value = v;

      send(isTop);
      update();
    }
    else
    {
        if(!timer.isActive())
        {
           timer.start();
        }
    }

    return true;
}

bool Dial::setMinValue(qreal v)             //������Сֵ
{
    if(v>value)
    {
        return false;
    }

    minvalue = v;

    if(minvalue>endvalue)
    {
        endvalue=minvalue;
    }

    update();

    return true;
}

bool Dial::setMaxValue(qreal v)             //�������ֵ
{
    if(v<value)
    {
        return false;
    }
    maxvalue = v;

    if(maxvalue<endvalue)
    {
        endvalue=maxvalue;
    }

    update();

    return true;
}

//һ������������ֵ:��ǰֵ,��Сֵ,���ֵ,�յ�ֵ
bool Dial::setValues(qreal cV,qreal minV,qreal maxV,qreal endV)
{
    bool ret=true;

    if((cV>=minV)&&(cV<=maxV)&&(endV>=minV)&&(endV<=maxV))
    {
        endvalue =endV;

        value = cV;

        minvalue = minV;

        maxvalue = maxV;

        update();
    }
    else
    {
        ret = false;
    }

    return ret;
}


/*����Բ�����ɫ*/
void Dial::setRoundColor(QColor obkColor,QColor bkColor,QColor centercolor)
{
    this->obkColor = obkColor;
    this->bkColor = bkColor;
    this->centercolor = centercolor;

    update();
}

/*����ָ�������ɫ*/
void Dial::setPointerColor(QColor PointerColor)
{
    this->PointerColor = PointerColor;
    update();

}

/*����������ɫ(�̶���ɫ,�����Ŀ̶���ɫ,����ֵ��ɫ,��ǩֵ��ɫ)*/
void Dial::setTextColor(QColor ScaleColor,QColor slideScaleColor,QColor ValueColor,QColor LabelColor)
{
    this->ScaleColor = ScaleColor;
    this->slideScaleColor = slideScaleColor;
    this->ValueColor = ValueColor;
    this->LabelColor = LabelColor;
    update();
}




