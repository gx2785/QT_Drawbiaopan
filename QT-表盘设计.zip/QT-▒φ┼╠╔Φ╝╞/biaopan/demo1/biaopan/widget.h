#ifndef WIDGET_H
#define WIDGET_H

#include <QtGui>
#include "Dial.h"
class widget : public QWidget
{
    Q_OBJECT

private:

    Dial  VDial;        //��ѹ��1
    Dial  VDia2;        //��ѹ��2

    Dial  RDia3;        //�����


    QSpinBox  slider1;

    QSpinBox  slider2;

    QSpinBox  slider3;

protected slots:

   void onvalueChanged1(int i);
   void onvalueChanged2(int i);
   void onvalueChanged3(int i);



public:
    explicit widget(QWidget *parent = 0);
    
signals:
    

    
};

#endif // WIDGET_H
