#include "widget.h"
widget::widget(QWidget *parent) :
    QWidget(parent),
    VDial(this,"��ѹ��","%1V",":V"),
    VDia2(this,"��ѹ��","%1V",":V"),
    RDia3(this,"�����","%1��",":R"),
    slider1(this),
    slider2(this),
    slider3(this)
{

    this->setStyleSheet("background:rgb(60,60,60);");


    VDial.setTimerType(100,3);   //���ö�ʱ������,ÿ������ms,�ܶ���ֵ
    VDial.setValues(0,0,240,0);
    VDial.setGradientColorMode(QList<QColor>()<<QColor(45,0,255)<<QColor(0,233,255)<<QColor(45,255,0)<<QColor(255,243,0)<<QColor(255,0,0));
                        //���ý���

    VDial.setMinimumSize(300,300);
    VDial.setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
    slider1.setMaximum(240);
    slider1.setMinimum(0);
    slider1.setValue(0);
    slider1.setFixedSize(110,40);
    slider1.setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
    slider1.setStyleSheet("background:rgb(255,255,255);");
    connect(&slider1,SIGNAL(valueChanged(int )),this,SLOT(onvalueChanged1(int )));

    VDia2.setTimerType(100,2.5);   //���ö�ʱ������,ÿ������ms,�ܶ���ֵ
    VDia2.setValues(0,0,120,0);
    VDia2.setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
    VDia2.setMinimumSize(300,300);

    slider2.setMaximum(120);
    slider2.setMinimum(0);
    slider2.setValue(0);
    slider2.setFixedSize(110,40);
    slider2.setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
    slider2.setStyleSheet("background:rgb(255,255,255);");
    connect(&slider2,SIGNAL(valueChanged(int )),this,SLOT(onvalueChanged2(int )));

    RDia3.setTimerType(100,2.5);   //���ö�ʱ������,ÿ������ms,�ܶ���ֵ
    RDia3.setValues(0,0,180,0);
    RDia3.setGradientColorMode( QList<QColor>()<<QColor(0,228,255)<<QColor(0,255,183)<<QColor(45,255,0)<<QColor(238,255,0));
    RDia3.setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
    RDia3.setMinimumSize(300,300);
    slider3.setMaximum(180);
    slider3.setMinimum(0);
    slider3.setValue(0);
    slider3.setFixedSize(110,40);
    slider3.setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
    slider3.setStyleSheet("background:rgb(255,255,255);");
    connect(&slider3,SIGNAL(valueChanged(int )),this,SLOT(onvalueChanged3(int )));

    QGridLayout* grid = new QGridLayout();

    grid->addWidget(&VDial,0,0,1,1);
    grid->addWidget(&VDia2,0,1,1,1);
    grid->addWidget(&RDia3,0,2,1,1);
    grid->addWidget(&slider1,1,0,Qt::AlignCenter);
    grid->addWidget(&slider2,1,1,Qt::AlignCenter);
    grid->addWidget(&slider3,1,2,Qt::AlignCenter);


    this->setLayout(grid);

}



void widget::onvalueChanged1(int i)
{
    VDial.setEndValue(i);

}
void widget::onvalueChanged2(int i)
{
    VDia2.setEndValue(i);

}
void widget::onvalueChanged3(int i)
{
    RDia3.setEndValue(i);
}
