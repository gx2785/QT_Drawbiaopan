#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);

    QList<QLineEdit *> edits  = this->findChildren<QLineEdit *>();

    foreach(QLineEdit *edit,edits)
    {
        //edit->setValidator(new QRegExpValidator(QRegExp("[.][-][a-fA-F0-9]+$"), this ));
        edit->setMaxLength(6);
    }


    dial = new Dial(NULL,"��ѹ��","%1V",":V");

    dial->setCurrentValue(60);




    qDebug()<<ui->widget->size() <<dial->size();

    dial->setGradientColorMode(QList<QColor>()<<QColor(0,94,255)<<QColor(0,253,255)<<QColor(0,255,119)<<QColor(255,243,0)<<QColor(255,0,0));


    QHBoxLayout *layout = new QHBoxLayout();

    layout->addWidget(dial);

    ui->widget->setLayout(layout);
    ui->widget->setStyleSheet("background:rgb(40,40,40);");
}

Form::~Form()
{
    delete ui;
}

void Form::on_lineEdit_20_editingFinished()
{

    uint data = ui->lineEdit_20->text().toUInt(0,16);

    if(data<=0xFFFFFF)
    {
        QColor color(data);

        QString back("background:rgb(%1,%2,%3);");

        ui->widget->setStyleSheet(back.arg(color.red()).arg(color.green()).arg(color.blue()));
        ui->lineEdit_20->setText(QString().sprintf("%06x",data));
    }
}

void Form::on_lineEdit_15_editingFinished()
{
    uint data = ui->lineEdit_15->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setobkColor(QColor(data));
       ui->lineEdit_15->setText(QString().sprintf("%06x",data));
   }
}

void Form::on_lineEdit_11_editingFinished()
{
    uint data = ui->lineEdit_11->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setbkColor(QColor(data));
       ui->lineEdit_11->setText(QString().sprintf("%06x",data));
   }
}

void Form::on_lineEdit_18_editingFinished()
{
    uint data = ui->lineEdit_18->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setcentercolor(QColor(data));
       ui->lineEdit_18->setText(QString().sprintf("%06x",data));
   }
}

void Form::on_lineEdit_17_editingFinished()
{
    uint data = ui->lineEdit_17->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setPointerColor(QColor(data));
       ui->lineEdit_17->setText(QString().sprintf("%06x",data));
   }
}

void Form::on_lineEdit_12_editingFinished()
{
    uint data = ui->lineEdit_12->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setLabelColor(QColor(data));
       ui->lineEdit_12->setText(QString().sprintf("%06x",data));
   }
}

void Form::on_lineEdit_21_editingFinished()
{
    uint data = ui->lineEdit_21->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setScaleColor(QColor(data));
       ui->lineEdit_21->setText(QString().sprintf("%06x",data));
   }
}

void Form::on_lineEdit_8_editingFinished()
{
    uint data = ui->lineEdit_8->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setslideScaleColor(QColor(data));
       ui->lineEdit_8->setText(QString().sprintf("%06x",data));
   }

}

void Form::on_lineEdit_16_editingFinished()
{
    uint data = ui->lineEdit_16->text().toUInt(0,16);
   if(data<=0xFFFFFF)
   {
       qDebug()<<data;
       dial->setValueColor(QColor(data));
       ui->lineEdit_16->setText(QString().sprintf("%06x",data));
   }

}

void Form::on_lineEdit_19_editingFinished()
{
    qreal data = ui->lineEdit_19->text().toFloat();

   if(!dial->setMaxValue(data))
   {

       ui->lineEdit_19->setText("");

   }
}

void Form::on_lineEdit_10_editingFinished()
{
    qreal data = ui->lineEdit_10->text().toFloat();

   if(!dial->setMinValue(data))
   {

       ui->lineEdit_10->setText("");
   }
}
void Form::on_lineEdit_9_editingFinished()
{
   qreal data = ui->lineEdit_9->text().toFloat();

   dial->setTimerType(100,(dial->MaxValue()-dial->MinValue())/40);


   if(!dial->setEndValue(data))
   {

       ui->lineEdit_9->setText("");
   }
}

void Form::on_lineEdit_14_editingFinished()
{
    int data = ui->lineEdit_14->text().toInt();

    if(!dial->set_Center_decimal(data))
    {

        ui->lineEdit_14->setText("");
    }


}

void Form::on_lineEdit_13_editingFinished()
{
    int data = ui->lineEdit_13->text().toInt();

    if(!dial->set_Scale_decimal(data))
    {

        ui->lineEdit_13->setText("");
    }
}
