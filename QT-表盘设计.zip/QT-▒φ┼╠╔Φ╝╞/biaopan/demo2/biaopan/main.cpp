#include <QtGui/QApplication>

#include "form.h"

void func()
{
    char s[]="gbk";
    QTextCodec::setCodecForTr(QTextCodec::codecForName(s));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName(s));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName(s));
}



int main(int argc, char *argv[])
{
    func();
    QApplication a(argc, argv);


    Form f;

    f.show();

    return a.exec();
}


