#ifndef QMYSQL_H
#define QMYSQL_H

#include <QObject>
#include<QtSql>

#include "ChartPara.h"
class QMySql : public QObject
{
private:
    QSqlDatabase m_SqlDB;
    bool    m_DBConnectStatus;//���ݿ�����״̬
public:
    QMySql();
    ~QMySql();
    bool    ConnectDB(QString sHostName,WORD wPort,QString sDB,QString sUser,QString sPwd);
    bool    GetStatus();
    bool    ExeCmd(QString sSql);
    void    QuerySql(QString sSql);
};

#endif // QMYSQL_H
