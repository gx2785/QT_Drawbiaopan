#include "myqttestdlg.h"
#include "QBitmap"
#include "QPainter"
#include <QMouseEvent>
#include "qdrawmainview.h"
#include "drawview.h"

myqttestDlg::myqttestDlg(QWidget *parent)
	: QDialog/*QWidget*/(parent)
{
	ui.setupUi(this);
	ui.checkBox->setChecked(true);
	bool bCheck = ui.checkBox->checkState();
	bCheck = ui.radioButton->isChecked();
	/*
	//����һ��λͼ
	QBitmap objBitmap(size());
	//QPainter������λͼ�ϻ滭
	QPainter painter(&objBitmap);
	//���λͼ���ο�(�ð�ɫ���)
	painter.fillRect(rect(),Qt::white);
	painter.setBrush(QColor(0,0,0));
	//��λͼ�ϻ�Բ�Ǿ���(�ú�ɫ���)
	painter.drawRoundedRect(this->rect(),5,5);
	//ʹ��setmask���˼���
	setMask(objBitmap);
	*/
	m_Type  =0;
	//DrawView * pMain = (DrawView*) parentWidget();//��ȡ������ָ��
// 	if(NULL!=pMain)
// 	    pMain->m_pDrawMainView->AddDraw();
}

myqttestDlg::~myqttestDlg()
{

}

void myqttestDlg::mousePressEvent(QMouseEvent *event)
{
	if (event->button() == Qt::LeftButton)
	{
		m_dragPos = event->globalPos() - frameGeometry().topLeft();
		event->accept();
	}
	//DrawView * pMain = (DrawView*) parentWidget();
// 	if(NULL!=pMain)
// 		pMain->m_pDrawMainView->AddDraw();
	m_Type++;
}

void myqttestDlg::mouseMoveEvent(QMouseEvent *event)
{
	if (event->buttons() & Qt::LeftButton)
		//if (event->button() == Qt::LeftButton) // not work
	{
		if (m_dragPos.y() < 510)
		{

			move(event->globalPos() - m_dragPos);

		}
		event->accept();
	}
}