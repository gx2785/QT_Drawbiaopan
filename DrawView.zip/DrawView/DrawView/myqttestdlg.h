#ifndef MYQTTESTDLG_H
#define MYQTTESTDLG_H

//#include <QWidget>
#include <QDialog>
#include "ui_myqttestdlg.h"

class myqttestDlg : public QDialog/*QWidget*/
{
	Q_OBJECT
public:
	int m_Type;
public:
	myqttestDlg(QWidget *parent = 0);
	~myqttestDlg();
protected:
	void mousePressEvent(QMouseEvent *event);
	void mouseMoveEvent(QMouseEvent *event);
private:
	Ui::myqttestDlg ui;
	QPoint  m_dragPos;
};

#endif // MYQTTESTDLG_H
