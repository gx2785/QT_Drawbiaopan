/********************************************************************************
** Form generated from reading UI file 'chartpropertiesdlg.ui'
**
** Created: Wed May 9 14:09:43 2018
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHARTPROPERTIESDLG_H
#define UI_CHARTPROPERTIESDLG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChartPropertiesDlg
{
public:
    QDialogButtonBox *buttonBox_ok;
    QGroupBox *groupBox;
    QComboBox *comboBox_type;
    QGroupBox *groupBox_2;
    QLineEdit *lineEdit_Name;
    QGroupBox *groupBox_3;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit_BoxID;
    QLabel *label_2;
    QLineEdit *lineEdit_BoxIndex;
    QPushButton *pushButton_rtdb;
    QGroupBox *groupBox_4;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QLineEdit *lineEdit_openBoxID;
    QLabel *label_6;
    QLineEdit *lineEdit_openBoxIndex;
    QPushButton *pushButton_open;
    QCheckBox *checkBox_YT;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *lineEdit__closeBoxID;
    QLabel *label_4;
    QLineEdit *lineEdit_closeBoxIndex;
    QPushButton *pushButton_close;
    QGroupBox *groupBox_5;
    QPushButton *pushButton_colorInit;
    QPushButton *pushButton_colorClose;
    QPushButton *pushButton_coloropen;
    QCheckBox *checkBox_init;
    QCheckBox *checkBox_close;
    QCheckBox *checkBox_open;
    QGroupBox *groupBox_6;
    QLabel *label_7;
    QSpinBox *spinBox_lindeSize;
    QGroupBox *groupBox_7;
    QLabel *label_9;
    QLineEdit *lineEdit_x0;
    QLineEdit *lineEdit_y0;
    QLabel *label_10;
    QLineEdit *lineEdit_y1;
    QLabel *label_11;
    QLineEdit *lineEdit_x1;
    QLabel *label_12;

    void setupUi(QDialog *ChartPropertiesDlg)
    {
        if (ChartPropertiesDlg->objectName().isEmpty())
            ChartPropertiesDlg->setObjectName(QString::fromUtf8("ChartPropertiesDlg"));
        ChartPropertiesDlg->resize(451, 552);
        buttonBox_ok = new QDialogButtonBox(ChartPropertiesDlg);
        buttonBox_ok->setObjectName(QString::fromUtf8("buttonBox_ok"));
        buttonBox_ok->setGeometry(QRect(90, 510, 341, 32));
        buttonBox_ok->setOrientation(Qt::Horizontal);
        buttonBox_ok->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        groupBox = new QGroupBox(ChartPropertiesDlg);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 10, 201, 51));
        comboBox_type = new QComboBox(groupBox);
        comboBox_type->setObjectName(QString::fromUtf8("comboBox_type"));
        comboBox_type->setGeometry(QRect(10, 20, 181, 21));
        groupBox_2 = new QGroupBox(ChartPropertiesDlg);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(240, 10, 201, 51));
        lineEdit_Name = new QLineEdit(groupBox_2);
        lineEdit_Name->setObjectName(QString::fromUtf8("lineEdit_Name"));
        lineEdit_Name->setGeometry(QRect(10, 20, 181, 21));
        groupBox_3 = new QGroupBox(ChartPropertiesDlg);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 70, 431, 61));
        layoutWidget = new QWidget(groupBox_3);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 20, 411, 27));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit_BoxID = new QLineEdit(layoutWidget);
        lineEdit_BoxID->setObjectName(QString::fromUtf8("lineEdit_BoxID"));

        horizontalLayout->addWidget(lineEdit_BoxID);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit_BoxIndex = new QLineEdit(layoutWidget);
        lineEdit_BoxIndex->setObjectName(QString::fromUtf8("lineEdit_BoxIndex"));

        horizontalLayout->addWidget(lineEdit_BoxIndex);

        pushButton_rtdb = new QPushButton(layoutWidget);
        pushButton_rtdb->setObjectName(QString::fromUtf8("pushButton_rtdb"));

        horizontalLayout->addWidget(pushButton_rtdb);

        groupBox_4 = new QGroupBox(ChartPropertiesDlg);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(10, 140, 431, 121));
        layoutWidget1 = new QWidget(groupBox_4);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 80, 407, 27));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_3->addWidget(label_5);

        lineEdit_openBoxID = new QLineEdit(layoutWidget1);
        lineEdit_openBoxID->setObjectName(QString::fromUtf8("lineEdit_openBoxID"));

        horizontalLayout_3->addWidget(lineEdit_openBoxID);

        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_3->addWidget(label_6);

        lineEdit_openBoxIndex = new QLineEdit(layoutWidget1);
        lineEdit_openBoxIndex->setObjectName(QString::fromUtf8("lineEdit_openBoxIndex"));

        horizontalLayout_3->addWidget(lineEdit_openBoxIndex);

        pushButton_open = new QPushButton(layoutWidget1);
        pushButton_open->setObjectName(QString::fromUtf8("pushButton_open"));

        horizontalLayout_3->addWidget(pushButton_open);

        checkBox_YT = new QCheckBox(groupBox_4);
        checkBox_YT->setObjectName(QString::fromUtf8("checkBox_YT"));
        checkBox_YT->setGeometry(QRect(340, 10, 61, 21));
        layoutWidget2 = new QWidget(groupBox_4);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(10, 40, 407, 27));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        lineEdit__closeBoxID = new QLineEdit(layoutWidget2);
        lineEdit__closeBoxID->setObjectName(QString::fromUtf8("lineEdit__closeBoxID"));

        horizontalLayout_2->addWidget(lineEdit__closeBoxID);

        label_4 = new QLabel(layoutWidget2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);

        lineEdit_closeBoxIndex = new QLineEdit(layoutWidget2);
        lineEdit_closeBoxIndex->setObjectName(QString::fromUtf8("lineEdit_closeBoxIndex"));

        horizontalLayout_2->addWidget(lineEdit_closeBoxIndex);

        pushButton_close = new QPushButton(layoutWidget2);
        pushButton_close->setObjectName(QString::fromUtf8("pushButton_close"));

        horizontalLayout_2->addWidget(pushButton_close);

        groupBox_5 = new QGroupBox(ChartPropertiesDlg);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(10, 270, 431, 111));
        pushButton_colorInit = new QPushButton(groupBox_5);
        pushButton_colorInit->setObjectName(QString::fromUtf8("pushButton_colorInit"));
        pushButton_colorInit->setGeometry(QRect(130, 20, 291, 23));
        pushButton_colorClose = new QPushButton(groupBox_5);
        pushButton_colorClose->setObjectName(QString::fromUtf8("pushButton_colorClose"));
        pushButton_colorClose->setGeometry(QRect(130, 50, 291, 23));
        pushButton_coloropen = new QPushButton(groupBox_5);
        pushButton_coloropen->setObjectName(QString::fromUtf8("pushButton_coloropen"));
        pushButton_coloropen->setGeometry(QRect(130, 80, 291, 23));
        checkBox_init = new QCheckBox(groupBox_5);
        checkBox_init->setObjectName(QString::fromUtf8("checkBox_init"));
        checkBox_init->setGeometry(QRect(10, 20, 111, 21));
        checkBox_close = new QCheckBox(groupBox_5);
        checkBox_close->setObjectName(QString::fromUtf8("checkBox_close"));
        checkBox_close->setGeometry(QRect(10, 50, 111, 21));
        checkBox_open = new QCheckBox(groupBox_5);
        checkBox_open->setObjectName(QString::fromUtf8("checkBox_open"));
        checkBox_open->setGeometry(QRect(10, 80, 111, 21));
        groupBox_6 = new QGroupBox(ChartPropertiesDlg);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setGeometry(QRect(10, 390, 211, 81));
        label_7 = new QLabel(groupBox_6);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 20, 31, 25));
        spinBox_lindeSize = new QSpinBox(groupBox_6);
        spinBox_lindeSize->setObjectName(QString::fromUtf8("spinBox_lindeSize"));
        spinBox_lindeSize->setGeometry(QRect(50, 20, 61, 22));
        groupBox_7 = new QGroupBox(ChartPropertiesDlg);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setGeometry(QRect(240, 390, 201, 81));
        label_9 = new QLabel(groupBox_7);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 20, 21, 25));
        lineEdit_x0 = new QLineEdit(groupBox_7);
        lineEdit_x0->setObjectName(QString::fromUtf8("lineEdit_x0"));
        lineEdit_x0->setGeometry(QRect(30, 20, 61, 21));
        lineEdit_y0 = new QLineEdit(groupBox_7);
        lineEdit_y0->setObjectName(QString::fromUtf8("lineEdit_y0"));
        lineEdit_y0->setGeometry(QRect(30, 50, 61, 21));
        label_10 = new QLabel(groupBox_7);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 50, 21, 25));
        lineEdit_y1 = new QLineEdit(groupBox_7);
        lineEdit_y1->setObjectName(QString::fromUtf8("lineEdit_y1"));
        lineEdit_y1->setGeometry(QRect(130, 50, 61, 21));
        label_11 = new QLabel(groupBox_7);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(110, 20, 21, 25));
        lineEdit_x1 = new QLineEdit(groupBox_7);
        lineEdit_x1->setObjectName(QString::fromUtf8("lineEdit_x1"));
        lineEdit_x1->setGeometry(QRect(130, 20, 61, 21));
        label_12 = new QLabel(groupBox_7);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(110, 50, 21, 25));

        retranslateUi(ChartPropertiesDlg);
        QObject::connect(buttonBox_ok, SIGNAL(accepted()), ChartPropertiesDlg, SLOT(accept()));
        QObject::connect(buttonBox_ok, SIGNAL(rejected()), ChartPropertiesDlg, SLOT(reject()));
        QObject::connect(pushButton_rtdb, SIGNAL(clicked()), ChartPropertiesDlg, SLOT(button_selectRtdb()));

        QMetaObject::connectSlotsByName(ChartPropertiesDlg);
    } // setupUi

    void retranslateUi(QDialog *ChartPropertiesDlg)
    {
        ChartPropertiesDlg->setWindowTitle(QApplication::translate("ChartPropertiesDlg", "Dialog", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("ChartPropertiesDlg", "\345\205\203\344\273\266\347\261\273\345\236\213", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("ChartPropertiesDlg", "\345\205\203\344\273\266\345\220\215\347\247\260", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QApplication::translate("ChartPropertiesDlg", "\345\256\236\346\227\266\346\225\260\346\215\256\345\256\232\344\271\211", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ChartPropertiesDlg", "\350\243\205\347\275\256ID", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("ChartPropertiesDlg", "\346\225\260\346\215\256\345\272\217\345\217\267", 0, QApplication::UnicodeUTF8));
        pushButton_rtdb->setText(QApplication::translate("ChartPropertiesDlg", "\346\225\260\346\215\256\345\272\223", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QApplication::translate("ChartPropertiesDlg", "\346\216\247\345\210\266\346\225\260\346\215\256\345\256\232\344\271\211", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("ChartPropertiesDlg", "\350\243\205\347\275\256ID", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("ChartPropertiesDlg", "\346\225\260\346\215\256\345\272\217\345\217\267", 0, QApplication::UnicodeUTF8));
        pushButton_open->setText(QApplication::translate("ChartPropertiesDlg", "\346\225\260\346\215\256\345\272\223(\345\210\206)", 0, QApplication::UnicodeUTF8));
        checkBox_YT->setText(QApplication::translate("ChartPropertiesDlg", "\350\256\276\347\275\256\345\200\274", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("ChartPropertiesDlg", "\350\243\205\347\275\256ID", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("ChartPropertiesDlg", "\346\225\260\346\215\256\345\272\217\345\217\267", 0, QApplication::UnicodeUTF8));
        pushButton_close->setText(QApplication::translate("ChartPropertiesDlg", "\346\225\260\346\215\256\345\272\223(\345\220\210)", 0, QApplication::UnicodeUTF8));
        groupBox_5->setTitle(QApplication::translate("ChartPropertiesDlg", "\351\242\234\350\211\262\345\256\232\344\271\211", 0, QApplication::UnicodeUTF8));
        pushButton_colorInit->setText(QString());
        pushButton_colorClose->setText(QString());
        pushButton_coloropen->setText(QString());
        checkBox_init->setText(QApplication::translate("ChartPropertiesDlg", "\345\210\235\345\247\213\347\212\266\346\200\201(\350\276\271\347\272\277)", 0, QApplication::UnicodeUTF8));
        checkBox_close->setText(QApplication::translate("ChartPropertiesDlg", "\345\220\210\351\227\270\347\212\266\346\200\201(\345\241\253\345\205\205)", 0, QApplication::UnicodeUTF8));
        checkBox_open->setText(QApplication::translate("ChartPropertiesDlg", "\345\210\206\351\227\270\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        groupBox_6->setTitle(QApplication::translate("ChartPropertiesDlg", "\345\237\272\346\234\254\345\261\236\346\200\247", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("ChartPropertiesDlg", "\347\272\277\345\256\275", 0, QApplication::UnicodeUTF8));
        groupBox_7->setTitle(QApplication::translate("ChartPropertiesDlg", "\344\275\215\347\275\256\345\261\236\346\200\247", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("ChartPropertiesDlg", "x0", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("ChartPropertiesDlg", "y0", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("ChartPropertiesDlg", "x1", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("ChartPropertiesDlg", "y1", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ChartPropertiesDlg: public Ui_ChartPropertiesDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHARTPROPERTIESDLG_H
