/********************************************************************************
** Form generated from reading UI file 'myqttestdlg.ui'
**
** Created: Wed May 9 14:09:44 2018
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYQTTESTDLG_H
#define UI_MYQTTESTDLG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QListView>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QTreeView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_myqttestDlg
{
public:
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QTreeView *treeView;
    QListView *listView;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;

    void setupUi(QWidget *myqttestDlg)
    {
        if (myqttestDlg->objectName().isEmpty())
            myqttestDlg->setObjectName(QString::fromUtf8("myqttestDlg"));
        myqttestDlg->resize(587, 594);
        checkBox = new QCheckBox(myqttestDlg);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(340, 100, 71, 16));
        checkBox_2 = new QCheckBox(myqttestDlg);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(440, 100, 71, 16));
        radioButton = new QRadioButton(myqttestDlg);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(340, 130, 89, 16));
        radioButton_2 = new QRadioButton(myqttestDlg);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(440, 130, 89, 16));
        treeView = new QTreeView(myqttestDlg);
        treeView->setObjectName(QString::fromUtf8("treeView"));
        treeView->setGeometry(QRect(10, 200, 256, 192));
        listView = new QListView(myqttestDlg);
        listView->setObjectName(QString::fromUtf8("listView"));
        listView->setGeometry(QRect(280, 200, 256, 192));
        horizontalLayoutWidget_2 = new QWidget(myqttestDlg);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(10, 190, 561, 231));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        widget = new QWidget(myqttestDlg);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 10, 500, 72));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(78, 70));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(78, 70));

        horizontalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(78, 70));

        horizontalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(78, 70));

        horizontalLayout->addWidget(pushButton_4);

        pushButton_5 = new QPushButton(widget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setMinimumSize(QSize(78, 70));

        horizontalLayout->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(widget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setMinimumSize(QSize(78, 70));

        horizontalLayout->addWidget(pushButton_6);


        retranslateUi(myqttestDlg);

        QMetaObject::connectSlotsByName(myqttestDlg);
    } // setupUi

    void retranslateUi(QWidget *myqttestDlg)
    {
        myqttestDlg->setWindowTitle(QApplication::translate("myqttestDlg", "myqttestDlg", 0, QApplication::UnicodeUTF8));
        checkBox->setText(QApplication::translate("myqttestDlg", "CheckBox", 0, QApplication::UnicodeUTF8));
        checkBox_2->setText(QApplication::translate("myqttestDlg", "CheckBox", 0, QApplication::UnicodeUTF8));
        radioButton->setText(QApplication::translate("myqttestDlg", "RadioButton", 0, QApplication::UnicodeUTF8));
        radioButton_2->setText(QApplication::translate("myqttestDlg", "RadioButton", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        pushButton->setToolTip(QApplication::translate("myqttestDlg", "\347\202\271\345\207\273\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        pushButton->setText(QApplication::translate("myqttestDlg", "\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        pushButton_2->setToolTip(QApplication::translate("myqttestDlg", "\347\202\271\345\207\273\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        pushButton_2->setText(QApplication::translate("myqttestDlg", "\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        pushButton_3->setToolTip(QApplication::translate("myqttestDlg", "\347\202\271\345\207\273\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        pushButton_3->setText(QApplication::translate("myqttestDlg", "\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        pushButton_4->setToolTip(QApplication::translate("myqttestDlg", "\347\202\271\345\207\273\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        pushButton_4->setText(QApplication::translate("myqttestDlg", "\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        pushButton_5->setToolTip(QApplication::translate("myqttestDlg", "\347\202\271\345\207\273\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        pushButton_5->setText(QApplication::translate("myqttestDlg", "\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        pushButton_6->setToolTip(QApplication::translate("myqttestDlg", "\347\202\271\345\207\273\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        pushButton_6->setText(QApplication::translate("myqttestDlg", "\346\214\211\351\222\256", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class myqttestDlg: public Ui_myqttestDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYQTTESTDLG_H
