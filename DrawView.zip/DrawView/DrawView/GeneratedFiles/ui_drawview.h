/********************************************************************************
** Form generated from reading UI file 'drawview.ui'
**
** Created: Wed May 9 14:09:43 2018
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DRAWVIEW_H
#define UI_DRAWVIEW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DrawViewClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *DrawViewClass)
    {
        if (DrawViewClass->objectName().isEmpty())
            DrawViewClass->setObjectName(QString::fromUtf8("DrawViewClass"));
        DrawViewClass->resize(600, 400);
        menuBar = new QMenuBar(DrawViewClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        DrawViewClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(DrawViewClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        DrawViewClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(DrawViewClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        DrawViewClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(DrawViewClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        DrawViewClass->setStatusBar(statusBar);

        retranslateUi(DrawViewClass);

        QMetaObject::connectSlotsByName(DrawViewClass);
    } // setupUi

    void retranslateUi(QMainWindow *DrawViewClass)
    {
        DrawViewClass->setWindowTitle(QApplication::translate("DrawViewClass", "DrawView", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DrawViewClass: public Ui_DrawViewClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DRAWVIEW_H
