#ifndef CHARTPROPERTIESDLG_H
#define CHARTPROPERTIESDLG_H

#include <QDialog>
 #include"ChartPara.h"

namespace Ui {
class ChartPropertiesDlg;
}

class ChartPropertiesDlg : public QDialog
{
    Q_OBJECT
    
public:
    void ModifyItemSelect(CHART_ITEM * Item_Select);
    void SetItemPara(CHART_ITEM * Item_Select);
    explicit ChartPropertiesDlg(QWidget *parent = 0);
    ~ChartPropertiesDlg();
protected slots:
    void button_selectRtdb();
private:
    Ui::ChartPropertiesDlg *ui;
};

#endif // CHARTPROPERTIESDLG_H
