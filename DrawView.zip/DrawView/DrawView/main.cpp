#include <QCoreApplication>
#include <QDebug>
#include <QtGui/QApplication>
#include <QtGui>
#include "drawview.h"
#include "candydialog.h"
#include "myqttestdlg.h"

void onTimerEvents()
{
    QSplashScreen *pSplash = new QSplashScreen();
    pSplash->setPixmap(QPixmap(":/images/button.png"));
    pSplash->show();
    pSplash->showMessage(QObject::tr("Starting..."),Qt::AlignRight|Qt::AlignTop,Qt::white);
}

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	QTextCodec::setCodecForTr(QTextCodec::codecForName("gb18030"));//֧��������ʾ
    //QTextCodec::setCodecForTr(QTextCodec::codecForName("utf-8"));
	//���������������ͼƬ

	QSplashScreen *pSplash = new QSplashScreen();
	pSplash->setPixmap(QPixmap(":/images/button.png"));
	pSplash->show();
	pSplash->showMessage(QObject::tr("Starting..."),Qt::AlignRight|Qt::AlignTop,Qt::white);
   // QTimer::singleShot(200,this,SLOT(app->processEvents()));
    QTimer::singleShot(200,&app,SLOT(onTimerEvents));
    //ʱ����200ms
	/*
	QApplication::setStyle(new QPlastiqueStyle);
	bool bReadFlg = false;
	QFile file(":/style.txt");
	  bReadFlg = file.open(QFile::ReadOnly);
	app.setStyleSheet(file.readAll());

	CandyDialog dialog;
	dialog.show();
	*/
	//myqttestDlg dlg;
	
	//if(dlg.exec()==QDialog::Accepted)
	//{
		DrawView w;
		w.show();
	//	pSplash->showMessage(QObject::tr("Starting ok..."),Qt::AlignRight|Qt::AlignTop,Qt::white);
		//pSplash->finish(&w);
	//}
	//
	
	
    delete pSplash;

	 
	return app.exec();
}
