#include "chartpropertiesdlg.h"
#include "ui_chartpropertiesdlg.h"

ChartPropertiesDlg::ChartPropertiesDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChartPropertiesDlg)
{
    ui->setupUi(this);
}

ChartPropertiesDlg::~ChartPropertiesDlg()
{
    delete ui;
}

void ChartPropertiesDlg::SetItemPara(CHART_ITEM * Item_Select)
{
    /*
    ChartDlg->m_x0 = Item_Select->Position.left;
    ChartDlg.m_x1 = Item_Select->Position.right;
    ChartDlg.m_y0 = Item_Select->Position.top;
    ChartDlg.m_y1 = Item_Select->Position.bottom;
    ChartDlg.m_linewidth = Item_Select->LineWidth;
    ChartDlg.m_filled = Item_Select->Filled;
    ChartDlg.m_startangle = Item_Select->StartAngle;
    ChartDlg.m_endangle = Item_Select->EndAngle;
    ChartDlg.m_linecolor = Item_Select->LineColor;
    ChartDlg.m_fillcolor = Item_Select->FillColor;
    ChartDlg.m_notLine = (Item_Select->Type != CHART_LINE);
    ChartDlg.m_bArc = (Item_Select->Type == CHART_ARC);
    ChartDlg.m_Not3D=TRUE;
    */
    ui->comboBox_type->setCursor(0);
    ui->lineEdit_Name->setText(Item_Select->Text);
    ui->lineEdit_x0->setText(QString::number(Item_Select->Position.left()));
    ui->lineEdit_x1->setText(QString::number(Item_Select->Position.right()));
    ui->lineEdit_y0->setText(QString::number(Item_Select->Position.top()));
    ui->lineEdit_y1->setText(QString::number(Item_Select->Position.bottom()));
    ui->lineEdit_BoxID->setText(QString::number(Item_Select->BoxID));
    ui->lineEdit_BoxIndex->setText(QString::number(Item_Select->BoxIndex));
    ui->lineEdit__closeBoxID->setText(QString::number(Item_Select->YkCloseBoxID));
    ui->lineEdit_closeBoxIndex->setText(QString::number(Item_Select->YkCloseBoxID));
    ui->lineEdit_openBoxID->setText(QString::number(Item_Select->YkOpenBoxID));
    ui->lineEdit_openBoxIndex->setText(QString::number(Item_Select->YkOpenBoxID));
    ui->spinBox_lindeSize->setValue(Item_Select->LineWidth);
    ui->checkBox_init->setChecked(Item_Select->ChangeFlag);
    ui->checkBox_close->setChecked(Item_Select->Filled ? true:false);


}

void ChartPropertiesDlg::ModifyItemSelect(CHART_ITEM * Item_Select)
{

}

void ChartPropertiesDlg::button_selectRtdb()
{
     //QColor color = QPalette::Window;
}
