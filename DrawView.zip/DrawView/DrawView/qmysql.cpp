#include "qmysql.h"

QMySql::QMySql()
{
    m_DBConnectStatus = false;
}
QMySql::~QMySql()
{
    m_SqlDB.close();

}
bool QMySql::ConnectDB(QString sHostName,WORD wPort,QString sDB,QString sUser,QString sPwd)
{
    m_SqlDB = QSqlDatabase::addDatabase("QMYSQL");
    m_SqlDB.setHostName(sHostName);
    m_SqlDB.setPort(wPort);
    m_SqlDB.setDatabaseName(sDB);
    m_SqlDB.setUserName(sUser);
    m_SqlDB.setPassword(sPwd);
    m_DBConnectStatus = m_SqlDB.open();
    if (m_DBConnectStatus)
    {

        qDebug() << QString("���ݿ�򿪳ɹ�");
    }
    else
    {
        qDebug() << "���ݿ��ʧ�ܣ�" << m_SqlDB.lastError();
    }
    return m_DBConnectStatus;
}
bool QMySql::GetStatus()
{
     m_DBConnectStatus= m_SqlDB.isOpen();
     return m_DBConnectStatus;
}

bool QMySql::ExeCmd(QString sSql)
{
    //SQL�������
    if(!m_SqlDB.isOpen()) {
        qDebug() << QString("���ݿ��ʧ��!");
        return false;
    }
    QSqlQuery query;
    return query.exec(sSql);
}

void QMySql::QuerySql(QString sSql)
{
    if(!m_SqlDB.isOpen()) {
        qDebug() << QString("���ݿ��ʧ��!");
        return  ;
    }
    QString id;
    QString name ;
    QSqlQuery query(sSql);
    //int iRowCount =query.size();
    while (query.next()) {
        //��ȡquery��ָ��ļ�¼�ڽ�����еı��
                //int rowNum = query.at();
                //��ȡÿ����¼���ֶΣ����У��ĸ���
                //int columnNum = query.record().count();

                //��ȡ"name"�ֶ������еı�ţ��д������ұ�ţ�����ߵı��Ϊ0
                int fieldNo = query.record().indexOf("name");
                name = query.value(fieldNo).toString();
             id = query.value(0).toString();
             name = query.value(1).toString();

       }
    /*
    int fieldNo = query.record().indexOf("id");
         while (query.next()) {
             QString country = query.value(fieldNo).toString();
             doSomething(country);
         }
         */
}
