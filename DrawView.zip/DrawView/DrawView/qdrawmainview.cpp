#include "qdrawmainview.h"
#include "drawview.h"
#include <QtGui>
//�������ļ���
#include <QtDebug>
#include <QFile>
#include <QDataStream>
#include <QDate>
//������
#include <QDesktopWidget> 
#include "chartpropertiesdlg.h"

QDrawMainView::QDrawMainView(QWidget *parent)
	: QWidget(parent)
{
	////
	selectMode = none;
	m_DrawToolsNo = 0;
	Item_Start = NULL;
	Item_Select = NULL;
	////
	 m_parent = parent;
	 pix =new QPixmap(size());      	//��QPixmap��������׼����ʱ���ջ��Ƶ�����
	 pix->fill(Qt::white);           //��䱳��ɫΪ��ɫ
	  


	InitData();
	ui.setupUi(this);
	this->setAutoFillBackground(true);
	QPalette palete;
     m_Color =QColor(0,0,0);
    palete.setColor(QPalette::Background,m_Color);
	//palette.setBrush(QPalette::Background, QBrush(QPixmap(":/background.png")));
	setPalette(palete);
	//
	m_updateTimer=new QTimer(this);
	m_updateTimer->setInterval(100);
	connect(m_updateTimer,SIGNAL(timeout()),this,SLOT(UpdateGraph()));
	m_updateTimer->start();
	QDesktopWidget *deskWgt = QApplication::desktop(); 
	if(deskWgt)
	{
        QRect rect = deskWgt->screenGeometry();
         m_Screensize = QSize(rect.width(),rect.height());
	}
    scale = 1;
       angle = 0;
       shear = 0;
}

QDrawMainView::~QDrawMainView()
{
	DeleteAll();
}

QSize QDrawMainView::GetScreenSize()
{
	return m_Screensize;
}

qreal QDrawMainView::GetScale()
{
	return scale;
}

void QDrawMainView::zoomIn()
{
    scale*=1.1;
    update();
}

void QDrawMainView::zoomOut()
{
    scale/=1.1;
    update();
}

void QDrawMainView::zoom_narmal()
{
    scale = 1;
    update();
}



void QDrawMainView::MergeSelectToComponent(BOOL BeUndo)
{
	CHART_ITEM * comp_info = new CHART_ITEM;

	QRect rect = Item_Select->Position;
	//rect.NormalizeRect();
	rect.normalized();
	if(rect.isEmpty())
		rect.translate(1, 1);

	CHART_ITEM * item_info = Item_Select->select;
	CHART_ITEM * item_temp;
	while(item_info != NULL)
	{
		item_temp = GetPriorItem(item_info);
		if(item_temp != NULL)
			item_temp->next = item_info->next;
		else
			Item_Start = item_info->next;

		QRect fix = item_info->Position;
		fix.normalized();
		if(fix.isEmpty())
			fix.translate(1, 1);
		rect |= fix;
		item_info = item_info->select;
	}

	item_temp = GetPriorItem(Item_Select);

	if(item_temp != NULL)
		item_temp->next = comp_info;
	else
		Item_Start = comp_info;
	comp_info->next = Item_Select->next;

	comp_info->Type = CHART_COMPONENT;
	comp_info->Text = " ";
	comp_info->Position = rect;
	comp_info->BoxID=9999;
	comp_info->BoxIndex=9999;
	comp_info->YkOpenBoxID=9999;
	comp_info->YkOpenBoxIndex = 9999;
	comp_info->YkCloseBoxID=9999;
	comp_info->YkCloseBoxIndex = 9999;
	comp_info->YkFlag=0;

	comp_info->LineColor = QColor(255,0,0);
	comp_info->LineWidth = 1;
	comp_info->FillColor = QColor(0,255,0);
	comp_info->Filled = FALSE;
	comp_info->EditColor =QColor(255,0,0);
	comp_info->StartAngle = 9999*0x10000+9999;
	comp_info->EndAngle = 9999*0x10000+9999;
	//comp_info->StrFont = pView->m_CurrentStrFont;
	comp_info->State = 2;
	comp_info->OldState = 0;
	if(Item_Select->Type == CHART_COMPONENT)
	{
		comp_info->LineWidth = 0x0010;
		comp_info->StartAngle = Item_Select->StartAngle;
		comp_info->EndAngle = Item_Select->EndAngle;
		comp_info->State = Item_Select->State;
	}
	comp_info->component = Item_Select;
	comp_info->select = NULL;

	int Width = rect.width();
	int Height = rect.height();
	item_info = Item_Select;
	while(item_info != NULL)
	{
		QPoint point=rect.topLeft( );
		//item_info->Position -= rect.getRect();//gx-180508
		QRect tempRect = item_info->Position;
		item_info->Position.setLeft( (long)(tempRect.left() * 10000.0 / Width));
		item_info->Position.setRight( (long)((tempRect.right() - tempRect.left() ) * 10000.0 / Width));
		item_info->Position.setTop( (long)(tempRect.top() * 10000.0 / Height));
		item_info->Position.setBottom((long)((tempRect.bottom() - tempRect.top() ) * 10000.0 / Height));
		item_info->next = item_info->select;
		item_info->select = NULL;
		item_info = item_info->next;
	}

	Item_Select = comp_info;
	if((comp_info->LineWidth & 0x0010) == 0x0010)
		SetMultiCompState(comp_info);

	if(BeUndo)
		ModifyChart( 5);

	//pView->InvalChart(comp_info->Position);
}

void QDrawMainView::SetMultiCompState(CHART_ITEM * comp)
{
	CHART_ITEM * temp = comp->component;
	while(temp != NULL)
	{
		if(temp->Type == CHART_COMPONENT)
		{
			temp->StartAngle = comp->StartAngle;
			temp->EndAngle = comp->EndAngle;
			temp->State = comp->State;
			if((temp->LineWidth & 0x0010) == 0x0010)
				SetMultiCompState(temp);
		}
		temp = temp->next;
	}
}

void QDrawMainView::ModifyChart(int function)
{
	//pView->GetDocument()->SetModifiedFlag();
	if(selectChanged || (lastDo != function && (!(lastDo == 1 && (function == 2 || function == 3)))))
	{
		selectChanged = FALSE;
		lastDo = function;
		if(Item_Select != NULL)
		{
			CHART_ITEM * chart_item = Item_Select;
			UNDO * undo;

			undo = new UNDO;
			undo->UndoType = function;
			undo->currentItem = chart_item;
			undo->priorItem = GetPriorItem(chart_item);
			undo->nextItem = NULL;
			undo->nextUndo = NULL;
			if(function == 3 || function == 9)
			{
				CHART_ITEM * propertyItem = Copy(chart_item,QPoint(0,0));
				undo->propertyItem = propertyItem;
			}
			else
				undo->propertyItem = NULL;

			UNDO * newUndo = undo;
			UNDO * prior = undo;

			chart_item = Item_Select->select;
			while(chart_item != NULL)
			{
				undo = new UNDO;
				undo->UndoType = function;
				undo->currentItem = chart_item;
				undo->priorItem = GetPriorItem(chart_item);
				undo->nextItem = NULL;
				undo->nextUndo = NULL;
				if(function == 3 || function == 9)
				{
					CHART_ITEM * propertyItem = Copy(chart_item,QPoint(0,0));
					undo->propertyItem = propertyItem;
				}
				else
					undo->propertyItem = NULL;
				undo->nextItem = prior;
				newUndo = undo;
				prior = undo;
				chart_item = chart_item->select;
			}

			newUndo->nextUndo = CurrentUndo;
			CurrentUndo = newUndo;
		}
	}

	if(!selectChanged && (lastDo == 1 && function == 2))		//����֮������ɾ�������������
	{
		UNDO * lastundo = CurrentUndo;
		CurrentUndo = lastundo->nextUndo;
		CHART_ITEM * property_item;
		UNDO * temp;
		while(lastundo != NULL)
		{
			if(lastundo->propertyItem != NULL)
			{
				property_item = lastundo->propertyItem;
				if(property_item->Type == CHART_COMPONENT || property_item->Type == CHART_UNION)
					DeleteComponent(property_item);
				else
					delete property_item;
			}
			temp = lastundo->nextItem;
			delete lastundo;
			lastundo = temp;
		}
	}
}

void QDrawMainView::MergeSelectToUnion(BOOL BeUndo)
{
	CHART_ITEM * comp_info = new CHART_ITEM;
	
	QRect rect = Item_Select->Position;
    rect.normalized();
    if(rect.isEmpty())
        rect.translate(1, 1);
	
	CHART_ITEM * item_info = Item_Select->select;
	CHART_ITEM * item_temp;
	while(item_info != NULL)
	{
		item_temp = GetPriorItem(item_info);
		if(item_temp != NULL)
			item_temp->next = item_info->next;
		else
			Item_Start = item_info->next;
		
		QRect fix = item_info->Position;
        fix.normalized();
        if(fix.isEmpty())
            fix.translate(1, 1);
		rect |= fix;
		item_info = item_info->select;
	}
	
	item_temp = GetPriorItem(Item_Select);
	
	if(item_temp != NULL)
		item_temp->next = comp_info;
	else
		Item_Start = comp_info;
	comp_info->next = Item_Select->next;
	
	comp_info->Type = CHART_UNION;
	comp_info->Text = " ";
	comp_info->Position = rect;
//	comp_info->LineColor = pView->m_CurrentLineColor;
    //comp_info->LineWidth = pView->m_CurrentLineWidth;
    //comp_info->FillColor = pView->m_CurrentFillColor;
    //comp_info->Filled = pView->m_CurrentFillMode;
	comp_info->StartAngle = 0;
	comp_info->EndAngle = 0;
//	comp_info->StrFont = pView->m_CurrentStrFont;
	comp_info->State = 0;
	comp_info->OldState = 0;
	comp_info->component = Item_Select;
	comp_info->select = NULL;
	
	item_info = Item_Select;
	while(item_info != NULL)
	{
        //item_info->Position -= rect.topLeft();//gx-180508
		item_info->next = item_info->select;
		item_info->select = NULL;
		item_info = item_info->next;
	}
	
	Item_Select = comp_info;
	
	if(BeUndo)
        ModifyChart( 7);
	
    //pView->InvalChart(comp_info->Position);
}

void QDrawMainView::BreakSelectUnion(BOOL BeUndo)
{
	CHART_ITEM * item_info = Item_Select;
	CHART_ITEM * item_temp;
	
	item_temp = GetPriorItem(item_info);
	if(item_temp != NULL)
		item_temp->next = item_info->component;
	else
		Item_Start = item_info->component;
	
	CHART_ITEM * next_info = item_info->next;
	
	item_temp = Item_Select->component;
	item_info = Item_Select;
    //QRect delta = item_info->Position.topleft();//gx-180508
	DeSelect( item_info);
	delete item_info;
	
	while(item_temp != NULL)
	{
        //item_temp->Position += delta;//gx-180508
		Select(item_temp,TRUE);
		item_info = item_temp;
		item_temp = item_temp->next;
	}
	item_info->next = next_info;
	
	if(BeUndo)
		ModifyChart( 8);
}

BOOL QDrawMainView::CanBeUndo()
{
	return(CurrentUndo != NULL);
}

void QDrawMainView::Undo()
{
	CHART_ITEM * chart_item;
	CHART_ITEM * prior_item;
	CHART_ITEM * property_item;

	InvalidateSelect();

	UNDO * undo = CurrentUndo;
	switch(undo->UndoType)
	{
	case 1:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			QRect rect = chart_item->Position;
			Delete(chart_item);
			//pView->InvalChart(rect);
			undo = undo->nextItem;
		}
		break;
	case 2:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			prior_item = undo->priorItem;
			CHART_ITEM * temp = chart_item;
			if(prior_item != NULL)
			{
				while(temp->next != NULL)
					temp = temp->next;
				temp->next = prior_item->next;
				prior_item->next = chart_item;
			}
			else
			{
				while(temp->next != NULL)
					temp = temp->next;
				temp->next = Item_Start;
				Item_Start = chart_item;
			}
			Select(chart_item, TRUE);
			undo = undo->nextItem;
		}
		break;
	case 3:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			property_item = undo->propertyItem;
			//pView->InvalChart(chart_item->Position);
			CopyProperty(property_item, chart_item);
			Select(chart_item, TRUE);
			undo = undo->nextItem;
		}
		break;
	case 4:
		CHART_ITEM * item_forward;
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			prior_item = undo->priorItem;
			item_forward = GetPriorItem(chart_item);
			if(item_forward != NULL)
				item_forward->next = chart_item->next;
			else
				Item_Start = chart_item->next;
			if(prior_item != NULL)
			{
				chart_item->next = prior_item->next;
				prior_item->next = chart_item;
			}
			else
			{
				chart_item->next = Item_Start;
				Item_Start = chart_item;
			}
			Select(chart_item, TRUE);
			undo = undo->nextItem;
		}
		break;
	case 5:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			Select( chart_item, FALSE);
			BreakSelectComponent( FALSE);
			undo = undo->nextItem;
		}
		break;
	case 6:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			Select( chart_item, TRUE);
			undo = undo->nextItem;
		}
		MergeSelectToComponent(FALSE);
		break;
	case 7:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			Select( chart_item, FALSE);
			BreakSelectUnion( FALSE);
			undo = undo->nextItem;
		}
		break;
	case 8:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			Select( chart_item, TRUE);
			undo = undo->nextItem;
		}
		MergeSelectToUnion( FALSE);
		break;
	case 9:
		while(undo != NULL)
		{
			chart_item = undo->currentItem;
			property_item = undo->propertyItem;
			CopyProperty(property_item, chart_item);
			Select( chart_item, TRUE);
			undo = undo->nextItem;
		}
		break;
	}

	undo = CurrentUndo;
	CurrentUndo = undo->nextUndo;
	UNDO * temp;
	while(undo != NULL)
	{
		if(undo->propertyItem != NULL)
		{
			property_item = undo->propertyItem;
			if(property_item->Type == CHART_COMPONENT || property_item->Type == CHART_UNION)
				DeleteComponent(property_item);
			else
				delete property_item;
		}
		temp = undo->nextItem;
		delete undo;
		undo = temp;
	}

	//pView->GetDocument()->SetModifiedFlag();
}



void QDrawMainView::BreakSelectComponent(BOOL BeUndo)
{
	CHART_ITEM * item_info = Item_Select;
	CHART_ITEM * item_temp;

	item_temp = GetPriorItem(item_info);
	if(item_temp != NULL)
		item_temp->next = item_info->component;
	else
		Item_Start = item_info->component;

	CHART_ITEM * next_info = item_info->next;

	item_temp = Item_Select->component;
	item_info = Item_Select;
	QPoint delta = item_info->Position.topLeft();
	int Width = item_info->Position.width();
	int Height = item_info->Position.height();
	DeSelect(item_info);
	delete item_info;

	while(item_temp != NULL)
	{
		QRect tempRect = item_temp->Position;
		item_temp->Position.setLeft((long)(tempRect.left() * Width / 10000.0));
		item_temp->Position.setRight((long)(tempRect.right() * Width / 10000.0 + item_temp->Position.left() ));
		item_temp->Position.setTop( (long)(tempRect.top() * Height / 10000.0));
		item_temp->Position.setBottom ( (long)(tempRect.bottom() * Height / 10000.0 + item_temp->Position.top() ));
		//item_temp->Position += delta;//gx-180508
		Select(item_temp,TRUE);
		item_info = item_temp;
		item_temp = item_temp->next;
	}
	item_info->next = next_info;

	if(BeUndo)
		ModifyChart( 6);
}

void QDrawMainView::CopyProperty(CHART_ITEM * source_info, CHART_ITEM * aim_info)
{
	aim_info->Type = source_info->Type;
	aim_info->Position = source_info->Position;
	aim_info->LineColor = source_info->LineColor;
	aim_info->LineWidth = source_info->LineWidth;
	aim_info->FillColor = source_info->FillColor;
	aim_info->Filled = source_info->Filled;
	aim_info->StartAngle = source_info->StartAngle;
	aim_info->EndAngle = source_info->EndAngle;
	aim_info->Text = source_info->Text;
	aim_info->StrFont = source_info->StrFont;
	aim_info->State = source_info->State;
	aim_info->OldState = source_info->OldState;

	if(source_info->Type == CHART_COMPONENT || source_info->Type == CHART_UNION)
		CopyComponentProperty(source_info, aim_info);
}

void QDrawMainView::CopyComponentProperty(CHART_ITEM * source_info, CHART_ITEM * aim_info)
{
	CHART_ITEM * source_temp = source_info->component;
	CHART_ITEM * aim_temp = aim_info->component;
	while(source_temp != NULL)
	{
		aim_temp->Type = source_temp->Type;
		aim_temp->Position = source_temp->Position;
		aim_temp->LineColor = source_temp->LineColor;
		aim_temp->LineWidth = source_temp->LineWidth;
		aim_temp->FillColor = source_temp->FillColor;
		aim_temp->Filled = source_temp->Filled;
		aim_temp->StartAngle = source_temp->StartAngle;
		aim_temp->EndAngle = source_temp->EndAngle;
		aim_temp->Text = source_temp->Text;
		aim_temp->StrFont = source_temp->StrFont;
		aim_temp->State = source_temp->State;
		aim_temp->OldState = source_temp->OldState;

		if(source_temp->Type == CHART_COMPONENT || source_temp->Type == CHART_UNION)
			CopyComponentProperty(source_temp, aim_temp);

		source_temp = source_temp->next;
		aim_temp = aim_temp->next;
	}
}



void QDrawMainView::Delete(CHART_ITEM * item_info)
{
	CHART_ITEM * item_temp = GetPriorItem(item_info);
	if(item_temp != NULL)
		item_temp->next = item_info->next;
	else
		Item_Start = item_info->next;

	if(item_info->Type == CHART_COMPONENT || item_info->Type == CHART_UNION)
		DeleteComponent(item_info);
	else
	{
		if(item_info->GalleryType==RTCurveChart)
		{
			for(int i=0;i<10;i++)
			{
				delete []item_info->ParChart[i].CurveValue;
			}
		}
		delete item_info;
	}
}

BOOL QDrawMainView::SerchItem(int nDataType, int nSpaceID, int nSpaceIndex, BOOL bSerchAll)
{
	CHART_ITEM * pitem;
	if(bSerchAll)
	{
		InvalidateSelect();
		pitem = Item_Start;
		while(pitem != NULL)
		{
			if(IsSerchConditionSuit(pitem, nDataType, nSpaceID, nSpaceIndex))
			{
				Select( pitem, TRUE);
			}
			pitem = pitem->next;
		}

		//MoveSelectedItemToCenter(pView);
		return(Item_Select != NULL);
	}
	else
	{
		if(Item_Select != NULL)
		{
			pitem = Item_Select->next;
			InvalidateSelect();
			while(pitem != NULL)
			{
				if(IsSerchConditionSuit(pitem, nDataType, nSpaceID, nSpaceIndex))
				{
					Select( pitem, FALSE);
					//MoveSelectedItemToCenter(pView);
					return(Item_Select != NULL);
				}
				pitem = pitem->next;
			}
		}

		pitem = Item_Start;
		while(pitem != NULL)
		{
			if(IsSerchConditionSuit(pitem, nDataType, nSpaceID, nSpaceIndex))
			{
				Select( pitem, FALSE);
				//MoveSelectedItemToCenter(pView);
				return(Item_Select != NULL);
			}
			pitem = pitem->next;
		}

		return FALSE;
	}
}

BOOL QDrawMainView::IsSerchConditionSuit(CHART_ITEM * pitem, int nDataType, int nSpaceID, int nSpaceIndex)
{
	BOOL isTypeSame = FALSE;
	BOOL isSpaceIDSame = FALSE;
	BOOL isSpaceIndexSame = FALSE;

	if(pitem->Type == CHART_COMPONENT && ((pitem->LineWidth & 0x0001) == 0 || (pitem->LineWidth & 0x0010) == 0x0010))
	{
		int switchType = ((pitem->LineWidth >> 8) & 0x0000000f) + 1;
		switch(nDataType)
		{
		case 0:	//ȫ��
			isTypeSame = TRUE;
			break;
		case 1:	//ң��
			if(switchType < 12 && switchType > 0)
				isTypeSame = TRUE;
			break;
		case 4:	//����״̬
			if(switchType == 12 || switchType == 13)
				isTypeSame = TRUE;
			break;
		case 5:	//����Ͷ��
			if(switchType == 14)
				isTypeSame = TRUE;
			break;
		case 6:	//��������״̬
			if(switchType == 15)
				isTypeSame = TRUE;
			break;
		}
	}
	else if(pitem->Type >= SIGNAL_2FLOAT && pitem->Type <= SIGNAL_0INT)
	{
		switch(nDataType)
		{
		case 0:	//ȫ��
			isTypeSame = TRUE;
			break;
		case 2:	//ң��
			if(pitem->Type < SIGNAL_2FLOAT)
				isTypeSame = TRUE;
			break;
		case 3:	//���
			if(pitem->Type >= SIGNAL_0INT)
				isTypeSame = TRUE;
			break;
		}
	}

	if(nSpaceID == -1 ||	//ȫ��
		nSpaceID == (int)(pitem->StartAngle & 0x0000ffff))
	{
		isSpaceIDSame = TRUE;
	}

	if(nSpaceIndex == -1 ||	//ȫ��
		nSpaceIndex == (int)(pitem->EndAngle & 0x0000ffff))
	{
		isSpaceIndexSame = TRUE;
	}

	return(isTypeSame && isSpaceIDSame &&  isSpaceIndexSame);
}

BOOL QDrawMainView::ReplaceData(int m_nReplaceDataType, int m_nReplaceSpaceID, int m_nReplaceSpaceIndex)
{
	BOOL changed = FALSE;
	WORD unlTemp;
	ModifyChart(9);
	CHART_ITEM * pitem = Item_Select;
	while(pitem != NULL)
	{
		if(m_nReplaceDataType != 0)	//���ǲ���
		{
		}
		if(m_nReplaceSpaceID != -1)	//���ǲ���
		{
			pitem->StartAngle &= 0xffff0000;
			unlTemp = (WORD)m_nReplaceSpaceID;
			pitem->StartAngle |= unlTemp;
			changed = TRUE;
		}
		if(m_nReplaceSpaceIndex != -1)	//���ǲ���
		{
			pitem->EndAngle &= 0xffff0000;
			unlTemp = (WORD)m_nReplaceSpaceIndex;
			pitem->EndAngle |= unlTemp;
			changed = TRUE;
		}
		pitem = pitem->select;
	}
	return changed;
}

CHART_ITEM * QDrawMainView::GetPriorItem(CHART_ITEM * item_info)
{
	CHART_ITEM * item_temp = Item_Start;
	if(item_temp == item_info)
		return NULL;
	while(item_temp->next != NULL)
	{
		if(item_temp->next == item_info)
			return item_temp;
		item_temp = item_temp->next;
	}
	//ASSERT(FALSE);
	return NULL;
}

 
void QDrawMainView::InvalidateSelect()
{
	CHART_ITEM * item_info;

	item_info = Item_Select;
	while(item_info != NULL)
	{
		//InvalChart(item_info->Position);
		Item_Select = item_info->select;
		item_info->select = NULL;
		item_info = Item_Select;
	}
}
void QDrawMainView::Select(CHART_ITEM * item_info, BOOL bAdd)
{
 	if (!bAdd)
 		InvalidateSelect();

	if(Item_Select == NULL)
		Item_Select = item_info;
	else if(IsSelected(item_info))
		DeSelect(item_info);
	else
	{
		CHART_ITEM * item_temp = GetLastSelect();
		item_temp->select = item_info;
	}
	//pView->InvalChart(item_info->Position);
	selectChanged = TRUE;
}

void QDrawMainView::SelectAll()
{
	InvalidateSelect();

	CHART_ITEM * item_info = Item_Start;
	while(item_info != NULL)
	{
		Select(item_info, TRUE);
		item_info = item_info->next;
	}
}
void QDrawMainView::DeleteSelect()
{
	CHART_ITEM * item_info = Item_Select;
	CHART_ITEM * temp;
	CHART_ITEM * prior;

	//�����������ݼ�¼�� UNDO ��
	ModifyChart(2);

	//���ڵ�ӽ���ͼ�ṹ��ȥ��
	while(item_info != NULL)
	{
		temp = item_info->select;
		DeSelect(item_info);
		prior = GetPriorItem(item_info);
		if(prior != NULL)
			prior->next = item_info->next;
		else
			Item_Start = item_info->next;
		item_info->next = NULL;
		//pView->InvalChart(item_info->Position);
		item_info = temp;
	}

	//CalculateChartSize(pView, NULL);
}


void QDrawMainView::DeleteAll()
{
	//ɾ������ͼ����
	CHART_ITEM * item_info = Item_Start;

	while(item_info != NULL)
	{
		Item_Start = item_info->next;
		delete item_info;
		item_info = Item_Start;
	}
}



CHART_ITEM * QDrawMainView::GetLastSelect()
{
	CHART_ITEM * item_info;
	 
	item_info = Item_Select;
	if(NULL==item_info) return NULL;
	while(item_info->select != NULL)
		item_info = item_info->select;
	return(item_info);
}


void QDrawMainView::DeSelect(CHART_ITEM * item_info)
{
	if(item_info == Item_Select)
		Item_Select = Item_Select->select;
	else
	{
		CHART_ITEM * item_temp = Item_Select;
		while(item_temp != NULL)
		{
			if(item_temp->select == item_info)
			{
				item_temp->select = item_info->select;
				break;
			}
			item_temp = item_temp->select;
		}
	}
	item_info->select = NULL;
	//pView->InvalChart(item_info->Position);
}

CHART_ITEM * QDrawMainView::ItemAt(const QPoint& point)
{
	QRect rect(point, QSize(1, 1));

	CHART_ITEM * item_info, * item_temp;
	item_info = Item_Start;
	item_temp = NULL;

	while (item_info != NULL)
	{
		QRect fixed = item_info->Position;
		//fixed.NormalizeRect();
		fixed.normalized();
		 
		if(item_info->Type == CHART_LINE)
		{
			int width = (item_info->LineWidth + 1)/2;
			fixed.setX(fixed.left() - width);
			fixed.setTop(fixed.top() - width);
			fixed.setRight(fixed.right() + width);
			fixed.setBottom(fixed.bottom() + width);
		}
		if(/*fixed.IsRectEmpty()*/fixed.isEmpty())
			//fixed.InflateRect(1, 1);
			fixed.translate(1,1);

		QRect rectT = rect;
		rectT.normalized();
		if(!(rectT & fixed).isEmpty())
			item_temp = item_info;
		item_info = item_info->next;
	}

	return item_temp;
}

bool QDrawMainView::IsSelected(CHART_ITEM * item_info)
{
	CHART_ITEM * item_temp = Item_Select;
	while(item_temp != NULL)
	{
		if(item_info == item_temp)
			return true;
		//if(NULL==item_temp->select) break;
		item_temp = item_temp->select;
	}
	return false;
}

void QDrawMainView::SelectItem(CHART_ITEM * item_info)
{
	 if(NULL==Item_Select)
		 Item_Select = item_info;
	 else if(IsSelected(item_info))
		 DeSelect(item_info);
	 else{
		 CHART_ITEM * item_temp = GetLastSelect();
		 item_temp->select = item_info;
	 }
}


void QDrawMainView::CloneSelection()
{
	CHART_ITEM * item_info = Item_Select;
	CHART_ITEM * item_temp;

	while (item_info != NULL)
	{
		// copies object and adds it to the document
        item_temp = Copy(item_info,QPoint(0,0));
		if(item_info->Type == CHART_COMPONENT)
			item_info->Filled = FALSE;	//����
		item_temp->next = item_info->next;
		item_info->next = item_temp;
		item_temp->select = NULL;
		item_info = item_info->select;
	}

	ModifyChart(1);
}

CHART_ITEM * QDrawMainView::Copy(CHART_ITEM * item_info, QPoint delta)
{
	CHART_ITEM * item_temp;
	if(item_info->Type == CHART_COMPONENT || item_info->Type == CHART_UNION)
		item_temp = CopyComponent(item_info,delta);
	else
	{
		item_temp = new CHART_ITEM;
		item_temp->Type = item_info->Type;
		item_temp->GalleryType =item_info->GalleryType;
		item_temp->ComponentType=item_info->ComponentType;
		item_temp->BoxID =item_info->BoxID;
		item_temp->BoxIndex =item_info->BoxIndex ;	
		item_temp->SpaceID=item_info->SpaceID;
		item_temp->SpaceIndex=item_info->SpaceIndex;
		item_temp->YkOpenBoxID=item_info->YkOpenBoxID;
		item_temp->YkOpenBoxIndex =item_info->YkOpenBoxIndex;
		item_temp->YkCloseBoxID =item_info->YkCloseBoxID;
		item_temp->YkCloseBoxIndex =item_info->YkCloseBoxIndex;
		item_temp->YkFlag=item_info->YkFlag;
        //item_temp->Position = item_info->Position + delta;//gx-180508
		item_temp->LineColor = item_info->LineColor;
		item_temp->LineWidth = item_info->LineWidth;
		item_temp->FillColor = item_info->FillColor;
		item_temp->Filled = item_info->Filled;
		item_temp->EditColor =item_info->EditColor;
		item_temp->StartAngle = item_info->StartAngle;
		item_temp->EndAngle = item_info->EndAngle;
		item_temp->Text = item_info->Text;
		item_temp->Unit	= item_info->Unit;
		item_temp->StrFont = item_info->StrFont;
		item_temp->State = item_info->State;
		item_temp->OldState = item_info->OldState;
		item_temp->Value=item_info->Value;
		item_temp->ManuFlag=item_info->ManuFlag;           //�˹�������־
		item_temp->ChangeFlag=item_info->ChangeFlag ;      //��λ��־
		item_temp->HangFlag=item_info->HangFlag;           //���Ʊ�־
		item_temp->HangText=item_info->HangText;           //�����ı�
		item_temp->DeviceID=item_info->DeviceID;           //�豸iD
		item_temp->component = NULL;
		item_temp->next = NULL;
		item_temp->select = NULL;	

		//��������
		item_temp->ParChart->ObjectCount=item_info->ParChart->ObjectCount;    //��ͼ������
		item_temp->ParChart->ObjectSN=item_info->ParChart->ObjectSN;          //��ͼ���ĸ�������
		item_temp->ParChart ->MinValue=item_info->ParChart->MinValue;         //��Сֵ
		item_temp->ParChart->MaxValue=item_info->ParChart->MaxValue;		  //���ֵ
		item_temp->ParChart ->Grid_H_Num =item_info->ParChart->Grid_H_Num;    //�߶ȿ̶ȸ������¶ȿ̶ȸ�������������
		item_temp->ParChart ->Grid_W_Num=item_info->ParChart->Grid_W_Num;	  //���ȿ̶ȸ�������������
		item_temp->ParChart->CurveCount=item_info->ParChart->CurveCount;      //����ʱ��

		if(item_info->GalleryType==RTCurveChart)
		{
			for(int i=0;i<10;i++)
			{
				item_temp->ParChart[i].CurveValue=new float[1800];
				for(int j=0;j<1800;j++)
				{
					item_temp->ParChart[i].CurveValue[j]=item_info->ParChart[i].CurveValue[j];
				}
			}
		}
		for(int i=0;i<10;i++)
		{
			item_temp->ParChart[i].ObjectID=item_info->ParChart[i].ObjectID;
			item_temp->ParChart[i].ObjectIndex=item_info->ParChart[i].ObjectIndex;
			item_temp->ParChart[i].ObjectName=item_info->ParChart[i].ObjectName;
			item_temp->ParChart[i].ObjectHeight=item_info->ParChart[i].ObjectHeight;
			item_temp->ParChart[i].ObjectColor=item_info->ParChart[i].ObjectColor;
			item_temp->ParChart[i].ObjectAlarmColor=item_info->ParChart[i].ObjectAlarmColor;
			item_temp->ParChart[i].CurveType=item_info->ParChart[i].CurveType;
		}
		//����	
		item_temp->TideChart.YCBoxID=item_info->TideChart.YCBoxID;
		item_temp->TideChart.YCBoxIndex=item_info->TideChart.YCBoxIndex;
		item_temp->TideChart.Direct=item_info->TideChart.Direct;
		item_temp->TideChart.YCValue=item_info->TideChart.YCValue;
		item_temp->TideChart.TideNodeCount=item_info->TideChart.TideNodeCount;

		//�¶ȼƣ�ת���Ǳ�
		item_temp->Thermometer.MinValue=item_info->Thermometer.MinValue;
		item_temp->Thermometer .MaxValue=item_info->Thermometer.MaxValue ;
		item_temp->Thermometer.Grid_H_Num =item_info->Thermometer.Grid_H_Num;
		item_temp->Thermometer.AlertOver=item_info->Thermometer.AlertOver;
		item_temp->Thermometer.AlertBelow=item_info->Thermometer.AlertBelow;
		item_temp->Thermometer.BelowColor=item_info->Thermometer.BelowColor;
		item_temp->Thermometer.OverColor=item_info->Thermometer.OverColor;
	}
	return item_temp;
}

CHART_ITEM * QDrawMainView::CopyComponent(CHART_ITEM * item_info, QPoint delta)
{
	CHART_ITEM * item_temp = new CHART_ITEM;
	item_temp->Type = item_info->Type;
	item_temp->GalleryType =item_info->GalleryType;
	item_temp->ComponentType=item_info->ComponentType;
	item_temp->BoxID =item_info->BoxID;
	item_temp->BoxIndex =item_info->BoxIndex ;	
	item_temp->SpaceID=item_info->SpaceID;
	item_temp->SpaceIndex=item_info->SpaceIndex;
	//item_temp->YkOpen=item_info->YkOpen;
	//item_temp->YkClose=item_info->YkClose;
	item_temp->YkOpenBoxID=item_info->YkOpenBoxID;
	item_temp->YkOpenBoxIndex =item_info->YkOpenBoxIndex;
	item_temp->YkCloseBoxID =item_info->YkCloseBoxID;
	item_temp->YkCloseBoxIndex =item_info->YkCloseBoxIndex;

	item_temp->YkFlag=item_info->YkFlag;
    //item_temp->Position = item_info->Position + delta;//gx-180508
	item_temp->LineColor = item_info->LineColor;
	item_temp->LineWidth = item_info->LineWidth;
	item_temp->FillColor = item_info->FillColor;
	item_temp->Filled = item_info->Filled;
	item_temp->EditColor =item_info->EditColor;
	item_temp->StartAngle = item_info->StartAngle;
	item_temp->EndAngle = item_info->EndAngle;
	item_temp->Text = item_info->Text;
	item_temp->Unit	= item_info->Unit;
	item_temp->StrFont = item_info->StrFont;
	item_temp->State = item_info->State;
	item_temp->OldState = item_info->OldState;
	item_temp->Value=item_info->Value;
	item_temp->ManuFlag=item_info->ManuFlag;           //�˹�������־
	item_temp->ChangeFlag=item_info->ChangeFlag ;      //��λ��־
	item_temp->HangFlag=item_info->HangFlag;           //���Ʊ�־
	item_temp->HangText=item_info->HangText;           //�����ı�
	item_temp->DeviceID=item_info->DeviceID;

	item_temp->component = NULL;
	item_temp->next = NULL;
	item_temp->select = NULL;	
	CHART_ITEM * pinfo = item_info->component;
	CHART_ITEM * ptemp1, * ptemp2;
	while(pinfo != NULL)
	{
		if(pinfo->Type == CHART_COMPONENT || pinfo->Type == CHART_UNION)
            ptemp1 = CopyComponent(pinfo,QPoint(0,0));
		else
		{
			ptemp1 = new CHART_ITEM;
			ptemp1->Type = pinfo->Type;
			item_temp->GalleryType =item_info->GalleryType;
			item_temp->ComponentType=item_info->ComponentType;
			item_temp->BoxID =item_info->BoxID;
			item_temp->BoxIndex =item_info->BoxIndex ;
			item_temp->SpaceID=item_info->SpaceID;
			item_temp->SpaceIndex=item_info->SpaceIndex;
// 			item_temp->YkOpen=item_info->YkOpen;
// 			item_temp->YkClose=item_info->YkClose;
			item_temp->YkOpenBoxID=item_info->YkOpenBoxID;
			item_temp->YkOpenBoxIndex =item_info->YkOpenBoxIndex;
			item_temp->YkCloseBoxID =item_info->YkCloseBoxID;
			item_temp->YkCloseBoxIndex =item_info->YkCloseBoxIndex;

			item_temp->YkFlag=item_info->YkFlag;
			ptemp1->Position = pinfo->Position;
			ptemp1->LineColor = pinfo->LineColor;
			ptemp1->LineWidth = pinfo->LineWidth;
			ptemp1->FillColor = pinfo->FillColor;
			ptemp1->Filled = pinfo->Filled;
			ptemp1->EditColor =pinfo->EditColor;
			ptemp1->StartAngle = pinfo->StartAngle;
			ptemp1->EndAngle = pinfo->EndAngle;
			ptemp1->Text = pinfo->Text;
			ptemp1->StrFont = pinfo->StrFont;
			ptemp1->State = pinfo->State;
			ptemp1->OldState = pinfo->OldState;
			item_temp->Value=item_info->Value;
			item_temp->ManuFlag=item_info->ManuFlag;           //�˹�������־
			item_temp->ChangeFlag=item_info->ChangeFlag ;      //��λ��־
			item_temp->HangFlag=item_info->HangFlag;           //���Ʊ�־
			item_temp->HangText=item_info->HangText;           //�����ı�
			item_temp->DeviceID=item_info->DeviceID;

			ptemp1->component = NULL;
			ptemp1->next = NULL;
			ptemp1->select = NULL;
		}
		if(item_temp->component == NULL)
			item_temp->component = ptemp1;
		else
			ptemp2->next = ptemp1;
		ptemp2 = ptemp1;
		pinfo = pinfo->next;
	}
	return item_temp;
}

int QDrawMainView::GetSelectCount()
{
	int count = 0;
	CHART_ITEM * item_info = Item_Select;
	while(item_info != NULL)
	{
		count ++;
		item_info = item_info->select;
	}
	return count;
}


QPoint QDrawMainView::GetHandle(int nHandle,QRect position)
{
	int x, y, xCenter, yCenter;

	xCenter = position.left() + position.width() / 2;
	yCenter = position.top() + position.height() / 2;

	switch (nHandle)
	{
	default:
	case 1:
		x = position.left();
		y = position.top();
		break;

	case 2:
		x = xCenter;
		y = position.top();
		break;

	case 3:
		x = position.right();
		y = position.top();
		break;

	case 4:
		x = position.right();
		y = yCenter;
		break;

	case 5:
		x = position.right();
		y = position.bottom();
		break;

	case 6:
		x = xCenter;
		y = position.bottom();
		break;

	case 7:
		x = position.left();
		y = position.bottom();
		break;

	case 8:
		x = position.left();
		y = yCenter;
		break;
	}

	return QPoint(x, y);
}

void QDrawMainView::InitData()
{
    m_JxtType = 0;
	m_DrawToolsNo = 0;
}
void QDrawMainView::rotateMap()
{
	 
}

void QDrawMainView::setBackgroundColor(QColor Rgb)
{
	QPalette palete;
	palete.setColor(QPalette::Background,Rgb);
	//palette.setBrush(QPalette::Background, QBrush(QPixmap(":/background.png")));
	setPalette(palete);
}
void QDrawMainView::SetDrawType(int iDrawType)
{
	m_DrawToolsNo = iDrawType;
	memset(m_Point,0,sizeof(QPoint)*MAX_POINT);
}
void QDrawMainView::drawLine(QPainter* painter,CHART_ITEM * item_info,QPoint delta)
{
	 //painter->save();
	 QPen pen(item_info->LineColor,item_info->Filled ? item_info->LineWidth : 1,item_info->Filled ? Qt::SolidLine : Qt::DashLine);
	 painter->setPen(pen); 
	
	 QRect rect = item_info->Position;
     //rect += delta;
     //rect += QRect(QPoint(0,0),delta);
	 if(rect.left()<=rect.right())
	 {
		 painter->drawLine(rect.left(),rect.top(),rect.right(),rect.bottom());
	 }
	 else{
		 painter->drawLine(rect.right(),rect.bottom(),rect.left(),rect.top());
	 }
	 //painter->drawLine(m_Point[0],m_Point[1]);
	 //painter->restore();
}

void QDrawMainView::drawCircle(QPainter* painter,CHART_ITEM * item_info,QPoint delta)
{
	//painter->save();
	QPoint pCenter;
	int iWidth,iHeight ;
	int x1,y1;
	int x2,y2;
	QRect rect = item_info->Position;
	x1 = rect.x();
	y1 = rect.y();
 
	iWidth =  rect.width(); 
	
	iHeight =rect.height();
	 
	
	pCenter.setX(rect.x()+iWidth/2);
	pCenter.setY(rect.y()+iHeight/2);
	m_outerRadius=iWidth>iHeight ?  iHeight/2 : iWidth/2;
	/*
	QLinearGradient qLineGradient(x1,y1,x2,y2);
	qLineGradient.setColorAt(0.0,QColor(0,200,0));
	qLineGradient.setColorAt(0.5,QColor(0,255,0));
	qLineGradient.setColorAt(1.0,QColor(0,200,0));
	*/
	
	QRadialGradient outerGradient(pCenter,m_outerRadius,pCenter);
	outerGradient.setColorAt(0.0,QColor(0,255,0));
// 	outerGradient.setColorAt(0.5,QColor(0,200,0));
// 	outerGradient.setColorAt(0.8,QColor(0,2,0));
	//outerGradient.setColorAt(0.99,QColor(0,200,0));
	//outerGradient.setColorAt(1.0,QColor(0,0,0));

	painter->setPen(Qt::NoPen);
	painter->setBrush(outerGradient);
	painter->drawEllipse(pCenter,iWidth/2,iHeight/2);
	//painter->drawArc(rect,45,180);
	//painter->restore();
}


void QDrawMainView::drawRect(QPainter* painter,CHART_ITEM * item_info,QPoint delta)
{
	//painter->save();
 
	//m_outerRadius=iWidth>iHeight ?  iHeight/2 : iWidth/2;
	
	QLinearGradient qLineGradient(item_info->Position.x(),item_info->Position.y(),item_info->Position.x()+item_info->Position.width(),item_info->Position.y()+item_info->Position.height());
	qLineGradient.setColorAt(0.5,QColor(0,200,0));
	qLineGradient.setColorAt(1.0,QColor(0,200,200));
	
	
 
	painter->setPen(Qt::NoPen);
	painter->setBrush(qLineGradient);
	painter->drawRect(item_info->Position);
	//painter->restore();
}


void QDrawMainView::drawRoundRect(QPainter* painter)
{
    //painter->save();
	QPoint pCenter;
	int iWidth,iHeight ;
	int x1,y1;
	int x2,y2;
	x1 = m_Point[0].x();
	y1 = m_Point[0].y();
	x2 = m_Point[1].x();
	y2 = m_Point[1].y();

	if(x2>=x1)
		iWidth =  x2-x1;

	else 
		iWidth =  x1-x2;
	if(y2>=y1)
		iHeight = y2-y1;
	else
		iHeight = y1-y2;


	pCenter.setX(m_Point[0].x()+iWidth);
	pCenter.setY(m_Point[0].y()+iHeight);
	m_outerRadius=iWidth>iHeight ?  iHeight/2 : iWidth/2;
	
	QLinearGradient qLineGradient(x1,y1,x2,y2);
	qLineGradient.setColorAt(0.05,QColor(0,255,0));
	//qLineGradient.setColorAt(0.2,QColor(0,255,0));
	qLineGradient.setColorAt(0.8,QColor(0,200,0));
	//qLineGradient.setColorAt(1.0,QColor(0,128,0));
	//qLineGradient.setColorAt(1.05,QColor(0,255,0));
	



	painter->setPen(Qt::NoPen);
	painter->setBrush(qLineGradient);
	painter->drawRoundRect(x1,y1,iWidth,iHeight);
    //painter->restore();
}

void QDrawMainView::drawOuterCircle(QPainter* painter)
{
	m_center = rect().center();//��ȡ�����С
	m_outerRadius=width()>height() ? height()/2 : width()/2;
	painter->save();
	
	QRadialGradient outerGradient(m_center,m_outerRadius,m_center);
	outerGradient.setColorAt(0.0,QColor(130,130,130));
	outerGradient.setColorAt(0.9,QColor(130,130,130));
	outerGradient.setColorAt(0.95,QColor(200,200,200));
	outerGradient.setColorAt(1.0,QColor(130,130,130));

	painter->setPen(Qt::NoPen);
	painter->setBrush(outerGradient);
	painter->drawEllipse(m_center,m_outerRadius,m_outerRadius);

	painter->restore();
}

void QDrawMainView::drawImage(QPainter* painter,CHART_ITEM * item_info,QPoint delta)
{
    QString sBitmapFile = item_info->Text;//�ļ�·��
    QImage image(sBitmapFile);
    QRectF targetRect =image.rect();
    painter->drawImage(targetRect,image,targetRect);
}

void QDrawMainView::DeleteComponent(CHART_ITEM * item_info)
{
	CHART_ITEM * item_temp;
	CHART_ITEM * item_temp2;

	item_temp = item_info->component;
	while(item_temp != NULL)
	{
		item_temp2 = item_temp;
		item_temp = item_temp->next;

		if(item_temp2->Type == CHART_COMPONENT || item_temp2->Type == CHART_UNION)
			DeleteComponent(item_temp2);
		else
			delete item_temp2;
	}
	delete item_info;
}

void QDrawMainView::MoveTo(CHART_ITEM * item_info, QRect position)
{
	if (position == item_info->Position)
		return;

	//�����������ݼ�¼�� UNDO ��
	ModifyChart(3);

	//pView->InvalChart(item_info->Position);
	item_info->Position = position;
	//pView->InvalChart(item_info->Position);

	//CalculateChartItemRect(item_info);
}


void QDrawMainView::MoveHandleTo(CHART_ITEM * item_info, int nHandle, QPoint point, bool regulared)
{
	int width;
	int height;
	BOOL baseChart;
	switch (item_info->Type)
	{
	case CHART_LINE:
		baseChart = TRUE;
		break;

	case CHART_RECT:
		baseChart = TRUE;
		break;

	case CHART_BITMAP:
		baseChart = TRUE;
		break;

	case CHART_ARC:
		baseChart = TRUE;
		break;

	default:
		baseChart = FALSE;
		break;
	}

	if(item_info->Type == CHART_LINE && nHandle == 2)
		nHandle = 5;

	QRect position = item_info->Position;
	switch (nHandle)
	{
	default:
	case 1:
		if(baseChart && regulared)
		{
			width = abs(point.x() - position.right());
			height = abs(point.y() - position.bottom());
			if(width > (height * 2) && item_info->Type == CHART_LINE)
			{
				position.setLeft(point.x());
				position.setTop(position.bottom());
			}
			else if(height > (width * 2) && item_info->Type == CHART_LINE)
			{
				position.setLeft(position.right());
				position.setTop( point.y());
			}
			else if(width > height)
			{
				if(point.x()> position.right())
					position.setLeft(  position.right() + height);
				else
					position.setLeft( position.right() - height);
				position.setTop(  point.y());
			}
			else
			{
				position.setLeft(  point.x());
				if(point.y() > position.bottom())
					position.setTop(  position.bottom() + width);
				else
					position.setTop(  position.bottom() - width);
			}
		}
		else
		{
			position.setLeft( point.x());
			position.setTop(  point.y());
		}
		break;

	case 2:
		if(baseChart && regulared)
		{
			width = abs(position.right() - position.left());
			if(point.y() > position.bottom())
				position.setTop(  position.bottom() + width);
			else
				position.setTop(  position.bottom() - width);
		}
		else
			position.setTop(  point.y());
		break;

	case 3:
		if(baseChart && regulared)
		{
			width = abs(point.x() - position.left());
			height = abs(point.y() - position.bottom());
			if(width > height)
			{
				if(point.x() > position.left())
					position.setRight( position.left() + height);
				else
					position.setRight( position.left() - height);
				position.setTop(  point.y());
			}
			else
			{
				position.setRight(  point.x());
				if(point.y() > position.bottom())
					position.setTop(  position.bottom() + width);
				else
					position.setTop(  position.bottom() - width);
			}
		}
		else
		{
			position.setRight( point.x());
			position.setTop(  point.y());
		}
		break;

	case 4:
		if(baseChart && regulared)
		{
			height = abs(position.bottom() - position.top());
			if(point.x() > position.left())
				position.setRight(  position.left() + height);
			else
				position.setRight(  position.left() - height);
		}
		else
			position.setRight(  point.x());
		break;

	case 5:
		if(baseChart && regulared)
		{
			width = abs(point.x() - position.left());
			height = abs(point.y() - position.top());
			if(width > (height * 2) && item_info->Type == CHART_LINE)
			{
				position.setRight(  point.x());
				position.setBottom(  position.top());
			}
			else if(height > (width * 2) && item_info->Type == CHART_LINE)
			{
				position.setRight(  position.left());
				position.setBottom(  point.y());
			}
			else if(width > height)
			{
				if(point.x() > position.left())
					position.setRight(  position.left() + height);
				else
					position.setRight(position.left() - height);
				position.setBottom(point.y());
			}
			else
			{
				position.setRight(  point.x());
				if(point.y() > position.top())
					position.setBottom(position.top() + width);
				else
					position.setBottom( position.top() - width);
			}
		}
		else
		{
			position.setRight( point.x());
			position.setBottom(point.y());
		}
		break;

	case 6:
		if(baseChart && regulared)
		{
			width = abs(position.right() - position.left());
			if(point.y() > position.top())
				position.setBottom( position.top() + width);
			else
				position.setBottom( position.top() - width);
		}
		else
			position.setBottom( point.y());
		break;

	case 7:
		if(baseChart && regulared)
		{
			width = abs(point.x() - position.right());
			height = abs(point.y() - position.top());
			if(width > height)
			{
				if(point.x() > position.right())
					position.setLeft( position.right() + height);
				else
					position.setLeft( position.right() - height);
				position.setBottom( point.y());
			}
			else
			{
				position.setLeft( point.x());
				if(point.y() > position.top())
					position.setBottom( position.top() + width);
				else
					position.setBottom( position.top() - width);
			}
		}
		else
		{
			position.setLeft( point.x());
			position.setBottom( point.y());
		}
		break;

	case 8:
		if(baseChart && regulared)
		{
			height = abs(position.bottom() - position.top());
			if(point.x() > position.right())
				position.setLeft(position.right() + height);
			else
				position.setLeft( position.right() - height);
		}
		else
			position.setLeft(point.x());
		break;
	}

	MoveTo(item_info,position);
}



bool QDrawMainView::IsSelectOneComponent()
{
    if(GetSelectCount() == 1)
    {
        if(Item_Select->Type == CHART_COMPONENT)
            return true;
    }

    return false;
}

bool QDrawMainView::IsSelectOneUnion()
{
    if(GetSelectCount() == 1)
    {
        if(Item_Select->Type == CHART_UNION)
            return true;
    }

    return false;
}

bool QDrawMainView::IsSelectNoneUnion()
{
    CHART_ITEM * item_info = Item_Select;

    while(item_info != NULL)
    {
        if(item_info->Type == CHART_UNION)
            return false;
        item_info = item_info->select;
    }
    return true;
}


void QDrawMainView::SelectOnLButtonDown(int nFlags,const QPoint& point)
{
    QPoint local = point;
    m_MousePt = local;
    m_MovePressPt =m_Point[0] = local;
      //  pView->ClientToDoc(local);

        CHART_ITEM * pItem;
        selectMode = none;

        // Check for resizing (only allowed on single selections)
        if (GetSelectCount() == 1 && !IsSelectOneUnion())
        {
            CHART_ITEM * item_info = Item_Select;
            nDragHandle = HitTest(item_info, local, TRUE);
            if (nDragHandle != 0)
            {
                selectMode = SelectMode::moveSize;
            }
        }
        //
       if(none==selectMode)
       {
		   pItem =ItemAt(local);
		   if(pItem!=NULL)
		   {
			   selectMode = SelectMode::move;
			   Item_Select =pItem;
			   if(!IsSelected(pItem))
			   {
				   //��û��ѡ����
				   SelectItem(pItem);
			   }
		   }
		   else{
			   //û��ѡ�е���
			   Item_Select = NULL;
		   }
       }
}
void QDrawMainView::mouseMoveEvent(QMouseEvent* event)
{
	if(m_DrawToolsNo!=0)
	{
		m_Point[1] = event->pos();
		CHART_ITEM * item_info = GetChartItemPt();
		CalculateChartItemRect(item_info);
	}
	else
	{
		QPoint local = event->pos();
		
		/*
		if (selectMode == netSelect)
		{
			QRect rect(m_Point[0].x(), m_Point[0].y(), m_Point[1].x(), m_Point[1].y());
			rect.normalized();
			//dc.DrawFocusRect(rect);
			rect.setRect(m_Point[1].x(), m_Point[1].y(), point.x, point.y);
			rect.normalized();
			//dc.DrawFocusRect(rect);

			//c_last = point;
			//SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));
			return;
		}
		*/
		QPoint delta = (QPoint)(local - m_MovePressPt);

		CHART_ITEM * item_info = Item_Select;
		while (item_info != NULL)
		{
			QRect position = item_info->Position;

			if (selectMode == SelectMode::move)
			{
				//position += delta;
				position.translate(delta);//ƽ��ͼ������
				MoveTo(item_info, position);
			}
			else if (nDragHandle != 0)
			{
				MoveHandleTo(item_info, nDragHandle, local, 0);
			}
			item_info = item_info->select;
		}
		m_MovePressPt = local;//������Ҫ�����ƶ���ʼ��
	}
	if(m_parent!=NULL)
	{
		((DrawView *)m_parent)->SetMousePostion(event->pos());
	}
}
void QDrawMainView::mousePressEvent(QMouseEvent* event)
{
	 CHART_ITEM * pItem;
	 QPoint local;
     m_Point[0] = event->pos();
     m_Point[1] = event->pos();
 
     switch(m_DrawToolsNo)
	 {
     case 0:
         SelectOnLButtonDown(0,m_Point[0]);
         break;
     case 1:
     case 2:
     case 4:
     case 6:
     case 8:
     case 16:
     case 32:
     case 64:
     case 128:
     case 129:
     {
         CHART_ITEM * item_info;
		 QPoint delta(0,0);
		 item_info =AddChartItem(m_Point[0]);
		  /*
		  CHART_ITEM * item_temp = GetLastSelect();
		  if(item_temp!=NULL)
		       item_temp->select = item_info;//��󻭵ľ���ѡ���
		  else{
			  Item_Select =item_info;
		  }*/
		  Item_Select =item_info;
         }
         break;
	}


		//ѡ��ͼԪ
        /*
		m_MousePt = event->pos();
		m_MovePressPt =m_Point[0] = event->pos();
		  local = event->pos();
		pItem =ItemAt(local);
		if(pItem!=NULL)
        {
			selectMode = SelectMode::move;
			Item_Select =pItem;
			 if(!IsSelected(pItem))
			 {
				 //��û��ѡ����
				 SelectItem(pItem);
			 }
		}
        */

	////////////////////
    /*
	if(GetSelectCount()==1)
	{
		//ѡ������ֻ��һ���ѡ��״̬-����ͼ��λ�õ���
		local = event->pos();
		CHART_ITEM * pSelect = Item_Select;
		nDragHandle = HitTest(pSelect, local, true);
		if (nDragHandle != 0)
		{
			selectMode = SelectMode::moveSize;			
		}
	}
    */
	
	 
}

void QDrawMainView::mouseReleaseEvent(QMouseEvent* event)
{
	CHART_ITEM * item_info;
	CHART_ITEM * item_temp;
	m_Point[1] = event->pos();
	if(m_DrawToolsNo!=0)
	 {
		item_info = GetChartItemPt();//��ȡ���һ��Ԫ��ָ��
		 QPoint delta(0,0);

		 CalculateChartItemRect(item_info);
		//AddDraw(item_info,delta);
		
	}
	else
	{
		 //�Ƿ���ѡ��ĳ��Ԫ��
        if(m_Point[0]==m_Point[1])
        {
            switch(m_DrawToolsNo)
            {
            case 0:
				{
					selectMode = SelectMode::none;
				}
                break;
            case 1:
            case 2:
            case 4:
            case 6:
            case 8:
            case 16:
            case 64:
				item_info = GetLastSelect();
				DeSelect( item_info);
				Delete(item_info);
				ModifyChart( 2);
				SelectOnLButtonDown(0, m_Point[1]); // try a select!
				break;
            case 32:
                break;
            }
        }
		else{
			CHART_ITEM * pSelectItem = Item_Select;
			while(pSelectItem!=NULL)
			{  
				if (selectMode == SelectMode::move ||selectMode==SelectMode::moveSize)
				{
					 
					//CalculateChartItemRect(pSelectItem);
					TranstateItem(pSelectItem,m_Point[1],m_MovePressPt);//ƽ��Ԫ��
				}
				else
				{
					
				}
				pSelectItem = pSelectItem->select;
			}
		}
	}
	if(m_Point[0]==m_Point[1])
	{
		m_DrawToolsNo = 0; 
	}
}

void QDrawMainView::wheelEvent(QWheelEvent *event)
{
	 
    if(event->delta()>0)
        zoomIn();//�Ŵ�
    else
        zoomOut();//��С
}

bool QDrawMainView::open(QString sFileName)
{
    QFile file(sFileName);
	if(!file.open(QIODevice::ReadOnly))
	{
		qDebug()<<"Error:file.open!!";
		return false;
	}
	QDataStream in(&file);
    //in.setByteOrder(QDataStream::LittleEndian);//Ĭ���Ǵ��ģʽ
     in >> m_JxtType;
     if(500000==m_JxtType||400000==m_JxtType)
    {
         in >> m_Screensize;
         in >> m_Color;
		 Item_Start = NULL;
         Serialize(in,JXT_READ,m_JxtType);
     }
	file.close();
	return true;
}

bool QDrawMainView::save(QString sFileName)
{
	//QString filename=QFileDialog::getSaveFileName(this,tr("Save File"),QString(),tr("Text Files(*.map);;Jxt Files(*.jxt)"));
	if(!sFileName.isEmpty())
	{
		QFile file(sFileName);
		file.open(QIODevice::WriteOnly | QIODevice::Truncate);
		QDataStream out(&file);  
        m_JxtType = (quint32)500000;
		out<<(quint32)500000;
        out<<m_Screensize;
        out<<m_Color;
        Serialize(out,JXT_WRITE,m_JxtType);

		file.close();
		return true;
	}
	else{
		return false;
	}

}
void QDrawMainView::AddDraw(QPainter *painter,CHART_ITEM * intem_info,QPoint delta)
{
	//QPainter *painter = new QPainter;
	//painter->begin(pix);
	//painter->setRenderHints(QPainter::Antialiasing|QPainter::TextAntialiasing);


	/*
	resetVariables(&painter);
	drawOuterCircle(&painter);
	drawInnerCircle(&painter);
	drawColorPies(&painter);
	drawGraph(&painter);
	drawCoverLines(&painter);
	drawCoverCircle(&painter);
	drawMarkAndText(&painter);

	drawTextRect(&painter);
	*/

	//drawOuterCircle(&painter);
    CHART_ITEM  charItem ;
    //m_arrayQlist.append(charItem);
	switch(intem_info->Type/*m_DrawToolsNo*/)
	{
	case CHART_LINE:
		drawLine(painter,intem_info,delta);
		break;
	case CHART_ARC:
		drawCircle(painter,intem_info,delta);
		break;
	case CHART_RECT:
		drawRect(painter,intem_info,delta);
		break;
	case CHART_BOUNDRECT:
		drawRoundRect(painter);
		break;
    case CHART_BITMAP:
        break;
	}
	//painter->end(); 
	//update();
}

CHART_ITEM * QDrawMainView::GetChartItemPt()
{
	CHART_ITEM * pItem = NULL;
	pItem = Item_Start;
	while(pItem->next != NULL)
		pItem = pItem->next;

	return pItem;
}

CHART_ITEM * QDrawMainView::AddChartItem(const QPoint& pointPress)
{
	CHART_ITEM * item_info;
	CHART_ITEM * item_temp;
	if(m_DrawToolsNo != 32)
	{
		if(Item_Start == NULL)
		{
			Item_Start = new CHART_ITEM;
			item_info = Item_Start;
		}
		else
		{
			item_info = new CHART_ITEM;
			item_temp = Item_Start;
			while(item_temp->next != NULL)
				item_temp = item_temp->next;
			
			item_temp->next = item_info;
		}		
		item_info->Position = QRect(pointPress, QSize(0, 0));
		
		item_info->LineColor = Qt::red;
		item_info->LineWidth = 2;
		item_info->FillColor = Qt::green;
		item_info->Filled = 1;
		item_info->EditColor= Qt::blue;
		item_info->StartAngle = 0;
		item_info->EndAngle = 0;
		item_info->BoxID =9999;
		item_info->BoxIndex =9999;
		item_info->SpaceID=9999;
		item_info->SpaceIndex=9999;
        item_info->YkOpenBoxID =9999;
        item_info->YkOpenBoxIndex = 9999;
        item_info->YkCloseBoxID =9999;
        item_info->YkCloseBoxIndex =9999;
		item_info->YkFlag=0;
        item_info->Text = "";
        //memset(item_info->Text,0,50);
        item_info->Unit	= "";
        //memset(item_info->Unit,0,50);
		item_info->StrFont = QFont();
		item_info->State = -1;
		item_info->OldState =2;
		item_info->Value=0;
		item_info->ManuFlag=0;
		item_info->ChangeFlag=0;
		item_info->HangFlag=0;
        item_info->HangText="";
        //qMemCopy(item_info->HangText,0,50);
		item_info->DeviceID=9999;
		
		item_info->next = NULL;
		item_info->component = NULL;
		item_info->select = NULL;
		switch(m_DrawToolsNo)
		{
		case 1:
			item_info->Type = CHART_LINE;
			item_info->Filled = TRUE;
			break;
		case 2:
			item_info->Type = CHART_ARC;
			break;
		case 3:
			item_info->Type = 3;
			break;
		case 4:
			item_info->Type = CHART_RECT;
			break;
		case 6:
			item_info->Type=CHART_3D;
			item_info->FillColor=QColor(0,255,0);
			item_info->EditColor=QColor(255,255,0);
			item_info->State = 2;
			break;
		case 8:
			item_info->Type = COMMON_STRING;
            item_info->Text = "Text";

			item_info->LineWidth = 0;
			item_info->Filled = TRUE;
			break;
		case 16:
			item_info->Type = SIGNAL_2FLOAT;
			item_info->Filled = TRUE;
			break;
		case 64:
			item_info->Type = CHART_BITMAP;
			item_info->LineWidth = 0;
			item_info->Filled = FALSE;
			item_info->LineColor = QColor(255, 255, 255);
			break;
		case 129:
			item_info->Type=CHART_OCX;
			break;
		case 256:
			item_info->Type=CHART_PTF;
			break;
		}
	}
	else
	{
		/*
		item_temp = Item_Lib;
		for(UINT i = 0; i < (m_DrawLibNo - 1); i++)
		{
			if(item_temp->next != NULL)
				item_temp = item_temp->next;
		}
		item_info = Copy(item_temp,CPoint(0,0));
		if(Item_Start == NULL)
		{
			Item_Start = item_info;
		}
		else
		{
			item_temp = Item_Start;
			while(item_temp->next != NULL)
				item_temp = item_temp->next;
			
			item_temp->next = item_info;
		}
		item_info->Position = CRect(point, CSize(0, 0));
		*/
	}
	
	//CalculateChartSize(pView, item_info);
	return(item_info);
}


void QDrawMainView::mouseDoubleClickEvent(QMouseEvent* event)
{
    if(m_DrawToolsNo !=0)
        return;
    if(GetSelectCount() != 1)
        return;

    ShowProperties();
}
//��ʾ�����ԡ��Ի���
void QDrawMainView::ShowProperties()
{
    /*
    //��ͼԪ���ߣ�Բ�����Σ�����
    ChartPropertiesDlg ChartDlg;
    //����λͼ����
    BitmapPropertiesDlg BitmapDlg;
    //������������
    StringPropertiesDlg StringDlg;
    //�����������
    SignalPropertiesDlg SignalDlg;
    //Ԫ������
    ComponentPropertiesDlg CompDlg;
    //��Ԫ����
    UnionPropertiesDlg UnionDlg;
    */
    //
    ChartPropertiesDlg *ChartDlg = new ChartPropertiesDlg(this);
    //ChartDlg->exec();


    //CRect rect;
    switch(Item_Select->Type)
    {
    case CHART_LINE:
    case CHART_ARC:
    case CHART_RECT:
        /*
        ChartDlg->m_x0 = Item_Select->Position.left;
        ChartDlg.m_x1 = Item_Select->Position.right;
        ChartDlg.m_y0 = Item_Select->Position.top;
        ChartDlg.m_y1 = Item_Select->Position.bottom;
        ChartDlg.m_linewidth = Item_Select->LineWidth;
        ChartDlg.m_filled = Item_Select->Filled;
        ChartDlg.m_startangle = Item_Select->StartAngle;
        ChartDlg.m_endangle = Item_Select->EndAngle;
        ChartDlg.m_linecolor = Item_Select->LineColor;
        ChartDlg.m_fillcolor = Item_Select->FillColor;
        ChartDlg.m_notLine = (Item_Select->Type != CHART_LINE);
        ChartDlg.m_bArc = (Item_Select->Type == CHART_ARC);
        ChartDlg.m_Not3D=TRUE;
    */
        ChartDlg->SetItemPara(Item_Select);
        if(ChartDlg->exec()==QDialog::Accepted)
        {

            //ModifyChart(9);
           // pView->InvalChart(Item_Select->Position);
            ChartDlg->ModifyItemSelect(Item_Select);
            /*
            Item_Select->Position.left = ChartDlg.m_x0;
            Item_Select->Position.right = ChartDlg.m_x1;
            Item_Select->Position.top = ChartDlg.m_y0;
            Item_Select->Position.bottom = ChartDlg.m_y1;
            Item_Select->LineWidth = ChartDlg.m_linewidth;
            Item_Select->Filled = ChartDlg.m_filled;
            if(Item_Select->Type == CHART_ARC)
                Item_Select->StartAngle = ChartDlg.m_startangle;
            else
                Item_Select->StartAngle = 0;
            Item_Select->EndAngle = ChartDlg.m_endangle;
            Item_Select->LineColor = ChartDlg.m_linecolor;
            Item_Select->FillColor = ChartDlg.m_fillcolor;
           // pView->InvalChart(Item_Select->Position);
           // CalculateChartSize(pView, Item_Select);
           */
        }
        break;
    case CHART_3D:
        //Show3DProperties(pView);
        break;

    case CHART_BITMAP:
        /*
        BitmapDlg.m_sBitmapFilename = Item_Select->Text;
        BitmapDlg.m_bClarity = Item_Select->Filled;
        BitmapDlg.m_ClarityColor = Item_Select->LineColor;
        BitmapDlg.m_nType = Item_Select->LineWidth;

        if(BitmapDlg.DoModal() == IDOK)
        {
            ModifyChart(pView, 9);
            pView->InvalChart(Item_Select->Position);
            Item_Select->LineWidth = BitmapDlg.m_nType;
            Item_Select->Text = BitmapDlg.m_sBitmapFilename;
            Item_Select->Filled = BitmapDlg.m_bClarity;
            Item_Select->LineColor = BitmapDlg.m_ClarityColor;
            Item_Select->StartAngle = BitmapDlg.m_nWidth;
            Item_Select->EndAngle = BitmapDlg.m_nHeight;
            pView->InvalChart(Item_Select->Position);
            CalculateChartSize(pView, Item_Select);
        }
        */
        break;

    case COMMON_STRING:
        /*
        StringDlg.m_x0 = Item_Select->Position.left;
        StringDlg.m_x1 = Item_Select->Position.right;
        StringDlg.m_y0 = Item_Select->Position.top;
        StringDlg.m_y1 = Item_Select->Position.bottom;
        StringDlg.m_text = Item_Select->Text;
        StringDlg.m_textcolor = Item_Select->LineColor;
        StringDlg.m_bClarity = Item_Select->Filled;
        StringDlg.m_textfont = Item_Select->StrFont;
        StringDlg.m_bLink	=Item_Select->State;
        StringDlg.m_strLink	=Item_Select->Unit;
        StringDlg.m_bFastKey = Item_Select->StartAngle;
        StringDlg.m_chFastKey = Item_Select->EndAngle;

        if(StringDlg.DoModal() == IDOK)
        {
            ModifyChart(pView, 9);
            pView->InvalChart(Item_Select->Position);
            Item_Select->Position.left = StringDlg.m_x0;
            Item_Select->Position.right = StringDlg.m_x1;
            Item_Select->Position.top = StringDlg.m_y0;
            Item_Select->Position.bottom = StringDlg.m_y1;
            Item_Select->Text = StringDlg.m_text;
            Item_Select->LineColor = StringDlg.m_textcolor;
            Item_Select->Filled = StringDlg.m_bClarity;
            Item_Select->StrFont = StringDlg.m_textfont;
            Item_Select->State	=StringDlg.m_bLink;
            Item_Select->Unit	=StringDlg.m_strLink;

            Item_Select->StartAngle = StringDlg.m_bFastKey;
            Item_Select->EndAngle = StringDlg.m_chFastKey;

            pView->InvalChart(Item_Select->Position);
            CalculateChartSize(pView, Item_Select);
        }*/
        break;

    case SIGNAL_2FLOAT:
    case SIGNAL_0INT:
    case SIGNAL_TIME:
        /*
        SignalDlg.m_x0 = Item_Select->Position.left;
        SignalDlg.m_x1 = Item_Select->Position.right;
        SignalDlg.m_y0 = Item_Select->Position.top;
        SignalDlg.m_y1 = Item_Select->Position.bottom;
        SignalDlg.m_nSignal = Item_Select->Type - 0x100;
        SignalDlg.m_nStationNo = Item_Select->BoxID;
        SignalDlg.m_nInStationNo = Item_Select->BoxIndex;
        SignalDlg.m_text = Item_Select->Text;
        SignalDlg.m_bShowUnit = Item_Select->Filled;
        SignalDlg.m_textcolor = Item_Select->LineColor;
        SignalDlg.m_textfont = Item_Select->StrFont;
        SignalDlg.m_unit	=Item_Select->Unit;

        SignalDlg.m_bIsSelectYC = Item_Select->StartAngle;
        if(SignalDlg.DoModal() == IDOK)
        {
            ModifyChart(pView, 9);
            pView->InvalChart(Item_Select->Position);
            Item_Select->Position.left = SignalDlg.m_x0;
            Item_Select->Position.right = SignalDlg.m_x1;
            Item_Select->Position.top = SignalDlg.m_y0;
            Item_Select->Position.bottom = SignalDlg.m_y1;
            Item_Select->Type = SignalDlg.m_nSignal + 0x100;
            Item_Select->BoxID = SignalDlg.m_nStationNo;
            Item_Select->BoxIndex = SignalDlg.m_nInStationNo;
            Item_Select->Text = SignalDlg.m_text;
            Item_Select->Unit	=SignalDlg.m_unit;
            Item_Select->Filled = SignalDlg.m_bShowUnit;
            Item_Select->LineColor = SignalDlg.m_textcolor;
            Item_Select->StrFont = SignalDlg.m_textfont;

        //	Item_Select->StartAngle = SignalDlg.m_bIsSelectYC;
            Item_Select->StartAngle = SignalDlg.m_wSelectType;

            pView->InvalChart(Item_Select->Position);
            CalculateChartSize(pView, Item_Select);
        }*/
        break;

    case CHART_COMPONENT:
        //ShowComponentProperties(pView);
        break;

    case CHART_UNION:
        /*
        UnionDlg.m_x0 = Item_Select->Position.left;
        UnionDlg.m_x1 = Item_Select->Position.right;
        UnionDlg.m_y0 = Item_Select->Position.top;
        UnionDlg.m_y1 = Item_Select->Position.bottom;
        UnionDlg.chart = this;

        if(UnionDlg.DoModal() == IDOK)
        {
            ModifyChart(pView, 9);
            pView->InvalChart(Item_Select->Position);
            Item_Select->Position.left = UnionDlg.m_x0;
            Item_Select->Position.right = UnionDlg.m_x1;
            Item_Select->Position.top = UnionDlg.m_y0;
            Item_Select->Position.bottom = UnionDlg.m_y1;
            pView->InvalChart(Item_Select->Position);
            CalculateChartSize(pView, Item_Select);
        }*/
        break;

    }
    if(ChartDlg!=NULL) delete ChartDlg;
        ChartDlg = NULL;
}

void QDrawMainView::UpdateGraph()
{
	update();
}
void QDrawMainView::paintEvent(QPaintEvent *)
{
	//�ػ��¼�
	QPainter painter(this);
	//painter.drawPixmap(QPoint(0,0),*pix);
	QRect tempRect;
	 CHART_ITEM * item_info = Item_Start;
	QPoint delta(0,0);
	painter.begin(pix);
	painter.setRenderHints(QPainter::Antialiasing|QPainter::TextAntialiasing);

	painter.save();
    //painter.scale(scale,scale);
    //painter.translate(m_Screensize.width()/2,m_Screensize.height()/2);
	 //painter.setWindow(m_MousePt.x(),m_MousePt.y(),m_Screensize.width(),m_Screensize.height());
	 //painter.setViewport(0,0,m_Screensize.width(),m_Screensize.height());
	while(item_info!=NULL)
	{
		//CalculateChartItemRect(item_info);
		tempRect = item_info->Position;
		tempRect.normalized();
		if(tempRect.isEmpty())
			tempRect.translate(1,1);
		 
	    AddDraw(&painter,item_info,delta);
		if(IsSelected(item_info))
		{
			//
			int nHandleCount = item_info->Type == CHART_LINE ? 2 : 8;

			for (int nHandle = 1; nHandle <= nHandleCount; nHandle += 1)
			{
				if(item_info->Type == CHART_LINE && nHandle == 2)
					nHandle = 5;
				QPoint handle = GetHandle(nHandle, item_info->Position);
				//painter.PatBlt(handle.x - 3, handle.y - 3, 7, 7, DSTINVERT);
				painter.setPen(Qt::white);
				painter.drawRect(handle.x() - 3, handle.y() - 3,7,7);
			}
		}
		item_info = item_info->next;
	}
 
	painter.restore();
	painter.end();
	
	
}
/************************************************************************/
/* resizeEvent����仯�¼�                                                                     */
/************************************************************************/
void QDrawMainView::resizeEvent(QResizeEvent *event)
{
	if(height()>pix->height()||width()>pix->width())
	{
// 		QPixmap *newPix = new QPixmap(size());
// 		newPix->fill(Qt::white);
// 		QPainter painter(newPix);
// 		painter.drawPixmap(QPoint(100,100),*pix);
// 		pix = newPix;
		 
	}
	QWidget::resizeEvent(event);
}


int QDrawMainView::HitTest(CHART_ITEM * item_info, QPoint point, bool bSelected)
{
	if (bSelected)
	{
		int nHandleCount = item_info->Type == CHART_LINE ? 2 : 8;
		QRect rc;
		for (int nHandle = 1; nHandle <= nHandleCount; nHandle += 1)
		{
			if(item_info->Type == CHART_LINE && nHandle == 2)
				nHandle = 5;
			// GetHandleRect returns in logical coords
			  rc = GetHandleRect(item_info,nHandle);
			if (point.x() >= rc.left() && point.x() < rc.right() &&
				point.y() <= rc.bottom() && point.y() > rc.top())
				return nHandle;
		}
	}
	else
	{
		QRect m_position = item_info->Position;
		if (point.x() >= m_position.left() && point.x() < m_position.right() &&
			point.y() <= m_position.bottom() && point.y() > m_position.top())
			return 1;
	}
	return 0;
}

QRect QDrawMainView::GetHandleRect(CHART_ITEM * item_info, int nHandleID)
{
	 
	QRect rect = item_info->Position;
	// get the center of the handle in logical coords
	QPoint point = GetHandle(nHandleID, rect);
	// convert to client/device coords
	//pView->DocToClient(point);
	// return CRect of handle in device coords
	//rect.setRect();
	rect.setRect(point.x()-3, point.y()-3, 12, 12);
	 
	//pView->ClientToDoc(rect);
	 
	return rect;
}

void QDrawMainView::CalculateChartItemRect(CHART_ITEM * item_info)
{
	int iTemp;
	iTemp =m_Point[0].x();
// 	if(iTemp>m_Point[1].x())
// 	{
// 		item_info->Position.setLeft(m_Point[1].x());
// 		item_info->Position.setRight(m_Point[0].x());
// 
// 	}
// 	else
	{
		item_info->Position.setLeft(m_Point[0].x());
		item_info->Position.setRight(m_Point[1].x());
	}
	iTemp = m_Point[0].y();
// 	if(iTemp>m_Point[1].y())
// 	{
// 		item_info->Position.setTop(m_Point[1].y());
// 		item_info->Position.setBottom(m_Point[0].y());
// 	}
// 	else
	{
		item_info->Position.setTop(m_Point[0].y());
		item_info->Position.setBottom(m_Point[1].y());
	}
}

void QDrawMainView::TranstateItem(CHART_ITEM * item_info,const QPoint local,const QPoint PressPoint)
{
	QPoint delta = (QPoint)(local - PressPoint);
	QRect position =item_info->Position;
	position.translate(delta);//ƽ��ͼ������
	MoveTo(item_info, position);
}

//����
void QDrawMainView::Serialize(QDataStream &ar,BYTE bRWType,quint32 JxtType)
{
    CHART_ITEM * item_info;
    BOOL notEmpty;
    m_JxtType=JxtType;
    if (1==bRWType)//����
    {
        if(Item_Start == NULL)
        {
            notEmpty = FALSE;
            ar << (quint16)notEmpty;
        }
        else
        {
            notEmpty = TRUE;
            ar << (quint16)notEmpty;
            item_info = Item_Start;
            while(item_info != NULL)
            {
                switch(item_info->Type)
                {
                case CHART_COMPONENT:
                case CHART_UNION:
                    SaveComponent(ar, item_info);
                    break;
                default:
                    SaveItem(ar, item_info);
                    break;
                }
                item_info = item_info->next;
            }
        }
    }
    else//��
    {
        DeleteAll();

        quint16 wTemp;
        ar >> wTemp;
        notEmpty = (BOOL)wTemp;

        if(notEmpty)
        {
            Item_Start = ReadItem(ar);

            CHART_ITEM * prior = Item_Start;
            while(prior != NULL)
            {
                if(prior->component != NULL)
                    ReadComponent(ar, prior);
                if(prior->next != NULL)
                {
                    item_info = ReadItem(ar);
                    prior->next = item_info;
                }
                prior = prior->next;
            }
        }
    }
}


CHART_ITEM * QDrawMainView::ReadItem(QDataStream& ar)
{
    WORD wTemp;
    WORD barTemp,TideTemp,TemthermometerTemp,ParticularChartTemp;
    BOOL nexted;
    WORD barnexted,Tidenexted,Temthermometernexted,ParticularChartnexted;
    CHART_ITEM * item_info = new CHART_ITEM;

    /***********��ȡ������Ϣ************/
    ar >> item_info->Type;
    ar >> item_info->GalleryType;
    ar >> item_info->ComponentType;
    ar >> item_info->BoxID;
    ar >> item_info->BoxIndex;
    if(m_JxtType==500000)
    {
        ar >> item_info->SpaceID;
        ar >> item_info->SpaceIndex;
    }
    ar >> item_info->YkOpenBoxID;
    ar >> item_info->YkOpenBoxIndex;
    ar >> item_info->YkCloseBoxID;
    ar >> item_info->YkCloseBoxIndex;
    ar >> item_info->YkFlag;
    ar >> item_info->Position;
    ar >> item_info->LineWidth;
    ar >> item_info->EditColor;
    ar >> item_info->LineColor;
    ar >> item_info->FillColor;
    ar >> wTemp; item_info->Filled = wTemp;
    ar >> item_info->StartAngle;
    ar >> item_info->EndAngle;
    ar >> item_info->Text;
    ar >> item_info->Unit;
    //ar.Read(&(item_info->StrFont), sizeof(LOGFONT));
    ar>>(QFont)item_info->StrFont;
    ar >> item_info->State;
    ar >> item_info->OldState;
    ar >> item_info->Value;
    ar >> item_info->ManuFlag;
    ar >> item_info->ChangeFlag;
    ar >> item_info->HangFlag;
    ar >> item_info->HangText;
    if(m_JxtType==500000)
        ar>>item_info->DeviceID;
    ar >> wTemp; nexted = (BOOL)wTemp;
    if(nexted == FALSE) item_info->next = NULL;
    else item_info->next = item_info;
    ar >> wTemp; nexted = (BOOL)wTemp;
    if(nexted == FALSE) item_info->component = NULL;
    else item_info->component = item_info;
    item_info->select = NULL;

    switch(item_info->GalleryType)
    {
    case RTBarChart:
    case RTCurveChart:
        ar>>barTemp;
        barnexted=(BOOL)barTemp;
        ReadBar(ar,item_info);
        break;
    case TideA:
    case TideB:
    case TideC:
    case TideD:
        ar>>TideTemp;
        Tidenexted=(BOOL)TideTemp;
        ReadTide(ar,item_info);
        break;
    case ThermoMeter:
    case RevMeter:
    case Water:
        ar>>TemthermometerTemp;
        Temthermometernexted=(BOOL)TemthermometerTemp;
        ReadTemthermometer(ar,item_info);
        break;
    default :
        ar>>ParticularChartTemp;
        ParticularChartnexted=(BOOL)ParticularChartTemp;
        break;
    }
/*	ar>>barTemp; barnexted=(BOOL)barTemp;
    if(barnexted==NULL)
    {
                item_info->ParChart=NULL;
    }
    else
        ReadBar(ar,item_info);

    ar>>TideTemp; Tidenexted=(BOOL)TideTemp;
    if(Tidenexted!=NULL)
        ReadTide(ar,item_info);

    ar>>TemthermometerTemp;Temthermometernexted=(BOOL)TemthermometerTemp;
    if(Temthermometernexted!=NULL)
        ReadTemthermometer(ar,item_info);
*/
    return item_info;
}

void QDrawMainView::ReadComponent(QDataStream& ar, CHART_ITEM * prior)
{
    CHART_ITEM * comp;
    comp = ReadItem(ar);
    prior->component = comp;

    prior = comp;
    while(prior != NULL)
    {
        if(prior->component != NULL)
            ReadComponent(ar, prior);
        if(prior->next != NULL)
        {
            comp = ReadItem(ar);
            prior->next = comp;
        }
        prior = prior->next;
    }
}


void QDrawMainView::SaveBar(QDataStream &ar, CHART_ITEM *item_info)
{
    //&&&&&&&&&&&&�����ͼ�����ߡ��¶ȼ���Ϣ&&&&&&&&&&&/

    for(int i=0;i<10;i++)
    {
        ar << item_info->ParChart[i].ObjectID;
        ar << item_info->ParChart[i].ObjectIndex;
        ar << item_info->ParChart[i].ObjectName;
        ar << item_info->ParChart[i].ObjectHeight;
        ar << item_info->ParChart[i].ObjectColor;
        ar << item_info->ParChart[i].ObjectAlarmColor;
        ar << item_info->ParChart[i].CurveType;
    }
    ar << item_info->ParChart->ObjectCount;     //��ͼ������
    ar << item_info->ParChart->ObjectSN;        //��ͼ���ĸ�������
    ar << item_info->ParChart->MinValue;        //��Сֵ
    ar << item_info->ParChart->MaxValue;		//���ֵ
    ar << item_info->ParChart->Grid_H_Num;      //�߶ȿ̶ȸ������¶ȿ̶ȸ�������������
    ar << item_info->ParChart->Grid_W_Num;	    //���ȿ̶ȸ�������������
    ar << item_info->ParChart->CurveCount;      //����ʱ��
    if(item_info->GalleryType==RTCurveChart)
    {
        for(int i=0;i<10;i++)
        {
            for(int j=0;j<1800;j++)
            {
                ar<<item_info->ParChart[i].CurveValue[j];
            }
        }
    }
}


void QDrawMainView::SaveTide(QDataStream &ar, CHART_ITEM *item_info)
{
    ar << item_info->TideChart.YCBoxID;
    ar << item_info->TideChart.YCBoxIndex;
    ar << item_info->TideChart.Direct;
    ar << item_info->TideChart.YCValue;
    ar << item_info->TideChart.TideNodeCount;
}

void QDrawMainView::ReadTide(QDataStream &ar, CHART_ITEM *item_info)
{
    ar >> item_info->TideChart.YCBoxID;
    ar >> item_info->TideChart.YCBoxIndex ;
    ar >> item_info->TideChart.Direct;
    ar >> item_info->TideChart.YCValue;
    ar >> item_info->TideChart.TideNodeCount;
}

void QDrawMainView::SaveThermometer(QDataStream &ar, CHART_ITEM *item_info)
{
    ar<<item_info->Thermometer.MinValue;      //��Сֵ
    ar<<item_info->Thermometer.MaxValue;	  //���ֵ
    ar<<item_info->Thermometer.Grid_H_Num;    //�߶ȿ̶ȸ���
    ar<<item_info->Thermometer.AlertOver;     //Խ���ޱ���
    ar<<item_info->Thermometer.AlertBelow;    //Խ���ޱ���
    ar<<item_info->Thermometer.OverColor ;    //Խ�Ͻ���ɫ
    ar<<item_info->Thermometer.BelowColor;    //Խ�½���ɫ
}

void QDrawMainView::ReadTemthermometer(QDataStream &ar, CHART_ITEM *item_info)
{
    ar>>item_info->Thermometer.MinValue;      //��Сֵ
    ar>>item_info->Thermometer.MaxValue;	  //���ֵ
    ar>>item_info->Thermometer.Grid_H_Num;    //�߶ȿ̶ȸ���
    ar>>item_info->Thermometer.AlertOver;     //Խ���ޱ���
    ar>>item_info->Thermometer.AlertBelow;    //Խ���ޱ���
    ar>>item_info->Thermometer.OverColor;     //Խ������ɫ
    ar>>item_info->Thermometer.BelowColor;    //Խ������ɫ
}

void QDrawMainView::ReadBar(QDataStream &ar, CHART_ITEM *item_info)
{
    //&&&&&&&&��ȡ��ͼ��Ϣ&&&&&&&&/
    for(int i=0;i<10;i++)
    {
        ar >>item_info->ParChart[i].ObjectID;
        ar >>item_info->ParChart[i].ObjectIndex;
        ar >>item_info->ParChart[i].ObjectName;
        ar >>item_info->ParChart[i].ObjectHeight;
        ar >>item_info->ParChart[i].ObjectColor;
        ar >>item_info->ParChart[i].ObjectAlarmColor;
        ar >>item_info->ParChart[i].CurveType;
    }
    ar >>item_info->ParChart->ObjectCount;       //��ͼ������
    ar >>item_info->ParChart->ObjectSN;          //��ͼ���ĸ�������
    ar >>item_info->ParChart->MinValue;          //��Сֵ
    ar >>item_info->ParChart->MaxValue;		     //���ֵ
    ar >>item_info->ParChart->Grid_H_Num;        //�߶ȿ̶ȸ������¶ȿ̶ȸ�������������
    ar >>item_info->ParChart->Grid_W_Num;		 //���ȿ̶ȸ�������������
    ar >>item_info->ParChart->CurveCount;        //����ʱ��
    if(item_info->GalleryType==RTCurveChart)
    {
        for(int i=0;i<10;i++)
        {
            item_info->ParChart[i].CurveValue=new float[1800];
            for(int j=0;j<1800;j++)
            {
                ar>>item_info->ParChart[i].CurveValue[j];
            }
        }
    }
}


void QDrawMainView::SaveItem(QDataStream & ar, CHART_ITEM * item_info)
{
    /***********���������Ϣ************/
    ar << item_info->Type;
    ar << item_info->GalleryType;
    ar << item_info->ComponentType;
    ar << item_info->BoxID;
    ar << item_info->BoxIndex;
    ar << item_info->SpaceID;
    ar << item_info->SpaceIndex;
    ar << item_info->YkOpenBoxID;
    ar << item_info->YkOpenBoxIndex;
    ar << item_info->YkCloseBoxID;
    ar << item_info->YkCloseBoxIndex;
    ar << item_info->YkFlag;
    ar << item_info->Position;
    ar << item_info->LineWidth;
    ar << item_info->EditColor;
    ar << item_info->LineColor;
    ar << item_info->FillColor;
    ar << (WORD)item_info->Filled;
    ar << item_info->StartAngle;
    ar << item_info->EndAngle;
    ar << item_info->Text;
    ar << item_info->Unit;
    //ar.Write(&(item_info->StrFont), sizeof(LOGFONT));
    ar <<(QFont)item_info->StrFont;
    ar << item_info->State;
    ar << item_info->OldState;
    ar << item_info->Value;
    ar << item_info->ManuFlag;
    ar << item_info->ChangeFlag;
    ar << item_info->HangFlag;
    ar << item_info->HangText;
    ar << item_info->DeviceID;

    BOOL nexted = TRUE;
    if(item_info->next == NULL)
        nexted = FALSE;
    ar << (WORD)nexted;
    if(item_info->component == NULL)
        nexted = FALSE;
    else
        nexted = TRUE;
    ar << (WORD)nexted;

    BOOL Bar=TRUE;
    BOOL Tide=TRUE;
    BOOL Thermometer=TRUE;
    BOOL ParticularChart=TRUE;
    switch(item_info->GalleryType)
    {
    case RTBarChart:
    case RTCurveChart:
        Bar = TRUE;
        ar<< (WORD)Bar;
        //SaveBar(ar,item_info);
        break;
    case TideA:
    case TideB:
    case TideC:
    case TideD:
        Tide=TRUE;
        ar<<(WORD)Tide;
        //SaveTide(ar,item_info);
        break;
    case ThermoMeter:
    case Water:
    case RevMeter:
        Thermometer=TRUE;
        ar<<(WORD)Thermometer;
       // SaveThermometer(ar,item_info);
        break;
    default :
        ParticularChart = FALSE;
        ar<< (WORD)ParticularChart;
        break;
    }

}

void QDrawMainView::SaveComponent(QDataStream& ar, CHART_ITEM * item_info)
{
    SaveItem(ar, item_info);
    CHART_ITEM * comp = item_info->component;
    while(comp != NULL)
    {
        switch(comp->Type)
        {
        case CHART_COMPONENT:
        case CHART_UNION:
            SaveComponent(ar, comp);
            break;
        default:
            SaveItem(ar,comp);
            break;
        }
        comp = comp->next;
    }
}
