#ifndef QDRAWMAINVIEW_H
#define QDRAWMAINVIEW_H

#define MAX_POINT 100

///////////////////
enum SelectMode
{
	none,
	netSelect,
	move,
	moveSize
};



//////////////////
#include <QWidget>
#include "ui_qdrawmainview.h"
#include <QtGui>
#include"ChartPara.h"

class QDrawMainView : public QWidget
{
	Q_OBJECT
protected:
    // �Ŵ�/��С
    void zoom_narmal();
    void zoomOut();
    void zoomIn();

	void mouseDoubleClickEvent(QMouseEvent* event);
	void mouseReleaseEvent(QMouseEvent* event);
	void mousePressEvent(QMouseEvent* event);
	void mouseMoveEvent(QMouseEvent* event);
	void paintEvent(QPaintEvent *);
	void resizeEvent(QResizeEvent* event);
public slots:
	void SetDrawType(int iDrawType);
private slots:
	void UpdateGraph();
    void ShowProperties();
public:
    bool IsSelectNoneUnion();
    bool IsSelectOneUnion();
    bool IsSelectOneComponent();
    void InvalidateSelect();
    void SelectOnLButtonDown(int nFlags,const QPoint& point);
	void MergeSelectToUnion(BOOL BeUndo);
	void BreakSelectUnion(BOOL BeUndo);
	void SetMultiCompState(CHART_ITEM * comp);
	void MergeSelectToComponent(BOOL BeUndo);
	void BreakSelectComponent(BOOL BeUndo);
	BOOL ReplaceData(int m_nReplaceDataType, int m_nReplaceSpaceID, int m_nReplaceSpaceIndex);
	BOOL IsSerchConditionSuit(CHART_ITEM * pitem, int nDataType, int nSpaceID, int nSpaceIndex);
	BOOL SerchItem(int nDataType, int nSpaceID, int nSpaceIndex, BOOL bSerchAll);
	void CopyComponentProperty(CHART_ITEM * source_info, CHART_ITEM * aim_info);
	void DeleteComponent(CHART_ITEM * item_info);
	void CopyProperty(CHART_ITEM * source_info, CHART_ITEM * aim_info);
	void Undo();
	BOOL CanBeUndo();
	
	void Delete(CHART_ITEM * item_info);
	void Select(CHART_ITEM * item_info, BOOL bAdd);
	void DeleteSelect();
	CHART_ITEM * GetPriorItem(CHART_ITEM * item_info);
	void	ModifyChart(int function);
	QSize GetScreenSize();
    qreal GetScale();
     void wheelEvent(QWheelEvent *event) ;
    //
    void ReadTemthermometer(QDataStream &ar, CHART_ITEM *item_info);
    void SaveThermometer(QDataStream &ar, CHART_ITEM *item_info);
    void ReadTide(QDataStream &ar, CHART_ITEM *item_info);
    void ReadBar(QDataStream &ar, CHART_ITEM *item_info);
    void ReadComponent(QDataStream& ar, CHART_ITEM * prior);
    CHART_ITEM * ReadItem(QDataStream& ar);
    void SaveTide(QDataStream &ar, CHART_ITEM *item_info);
    void SaveBar(QDataStream &ar, CHART_ITEM *item_info);
    void SaveComponent(QDataStream& ar, CHART_ITEM * item_info);
    void SaveItem(QDataStream & ar, CHART_ITEM * item_info);
    void Serialize(QDataStream &ar,BYTE bRWType,quint32 JxtType);
	bool open(QString sFileName);
	bool save(QString sFileName);
	QRect GetHandleRect(CHART_ITEM * item_info, int nHandleID);
	int HitTest(CHART_ITEM * item_info, QPoint point, bool bSelected);
	 
	void MoveHandleTo(CHART_ITEM * item_info, int nHandle, QPoint point, bool regulared);
	void MoveTo(CHART_ITEM * item_info, QRect position);
	QPoint GetHandle(int nHandle,QRect position);
	CHART_ITEM * GetLastSelect();

	//
	void SelectAll();
	void DeSelect(CHART_ITEM * item_info);
	void SelectItem(CHART_ITEM * item_info);
	bool IsSelected(CHART_ITEM * item_info);
	void CloneSelection();
	CHART_ITEM * Copy(CHART_ITEM * item_info, QPoint delta);
	CHART_ITEM * CopyComponent(CHART_ITEM * item_info, QPoint delta);
	int GetSelectCount();
	CHART_ITEM * ItemAt(const QPoint& point);
	CHART_ITEM * GetChartItemPt();
	void AddDraw(QPainter *painter,CHART_ITEM * intem_info,QPoint delta);
	void rotateMap();
	void setBackgroundColor(QColor Rgb);
	void drawRoundRect(QPainter* painter);
	void drawRect(QPainter* painter,CHART_ITEM * item_info,QPoint delta);
	void drawCircle(QPainter* painter,CHART_ITEM * item_info,QPoint delta);//��Բ
	void drawLine(QPainter* painter,CHART_ITEM * item_info,QPoint delta);//����
	void drawOuterCircle(QPainter* painter);
    void drawImage(QPainter* painter,CHART_ITEM * item_info,QPoint delta);
	QDrawMainView(QWidget *parent = 0);
	~QDrawMainView();
private:
	void DeleteAll();
	void TranstateItem(CHART_ITEM * item_info,const QPoint local,const QPoint PressPoint);//ƽ��ʱ���¼���λ��
	void CalculateChartItemRect(CHART_ITEM * item_info);
	//CHART_ITEM * AddChartItem(const QPoint& point);
	CHART_ITEM * AddChartItem(const QPoint& pointPress);
	void InitData();
protected:
	CHART_ITEM * Item_Select;
	CHART_ITEM * Item_Start;
	UNDO * CurrentUndo;
	BOOL selectChanged;
	int lastDo;
private:
	QPoint m_MousePt;
    qreal scale;   //������
       int angle;     //�Ƕ�
       qreal shear;   //������
    //
    QColor m_Color;
	QSize m_Screensize;
    quint32 m_JxtType;
	int  selectMode ;
	int nDragHandle;
	QPoint  m_MovePressPt;
	QPoint  m_MoveRleasePt;

    QList<CHART_ITEM> m_arrayQlist;
	QPixmap *pix;
	 
	int   m_DrawToolsNo;//ͼ������
	int/*qreal*/ m_outerRadius;
	QPoint m_center;
	QPoint m_Point[MAX_POINT];
	QTimer* m_updateTimer;//ˢ�¼��

	QWidget *m_parent;//������
private:
	Ui::QDrawMainView ui;
	
};

#endif // QDRAWMAINVIEW_H
