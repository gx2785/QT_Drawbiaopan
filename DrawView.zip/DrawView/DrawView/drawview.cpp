
#include <QtGui>
#include "drawview.h"
#include "qdrawmainview.h"
#include "myqttestdlg.h"

DrawView::DrawView(QWidget *parent, Qt::WFlags flags)
	: QMainWindow(parent, flags)
{

	m_pDrawMainView = new QDrawMainView(this);
	this->setCentralWidget(m_pDrawMainView);
    scrollArea = new QScrollArea;
    //scrollArea->setBackgroundRole(QPalette::Dark);   //scrollArea����ı���ɫ��ΪDark
    scrollArea->setWidget(m_pDrawMainView);     //���������ӵ�scrollArea��
    scrollArea->widget()->setMinimumSize(m_pDrawMainView->GetScreenSize());  //scrollArea��ʼ����С��Ϊ800*600

    setCentralWidget(scrollArea);    //��scrollArea���뵽�����ڵ�������

    //startMySql();
   // startRedis();//����REDIS

	creatAction();
	createMenus();
	createToolBars();
	createStatusBar();
	//ui.setupUi(this);

	//
	setWindowIcon(QIcon(":/images/icon.png"));
	this->showMaximized();
	
}

DrawView::~DrawView()
{
	
}

void DrawView::startMySql()
{
    QMySql *pSql = new QMySql();
    pSql->ConnectDB("127.0.0.1",3306,"stakeparadb","root","123456");
    pSql->GetStatus();
    QString sSql;
    for(int k=0; k<10; k++)
    {
        sSql=QString("insert into test (id,name) values(%1,'%2')").arg(QString::number(k+10)).arg("name"+QString::number(k+10));
    pSql->ExeCmd(sSql);
    }
    sSql = "select * from test";
    pSql->QuerySql(sSql);
}
void DrawView::startRedis()
{
     qRedis *redis = new qRedis("localhost",6379);
	connect(redis, SIGNAL(returnData(qRedis::Reply)), this, SLOT(slotMessage(qRedis::Reply)));

	qRedis::Reply reply;

	if (!redis->openConnection())
	{
		qDebug() << "Could not connect to server...";
		exit(0);
	}

	qDebug() << "Connected to server...";
/*
	//qDebug() << "AUTH:" << redis->auth("redisZzZ");
    QString values = " {\"id:5411113430101\",\" filepath\":\"/home/bxd/0000.jpg\",\" externsion\":\"jpg\"}";
    qDebug()<<"LPUSH"<<redis->lpush("bxd",values);

	// Set and Get example
	qDebug() << "SET:" << redis->set("key", "\"Hello World\"");
	qDebug() << "GET:" << redis->get("key");

	// Append to Key example
	qDebug() << "SET:" << redis->set("key", "\"Hello\"");
	qDebug() << "EXISTS:" << redis->exists("key");
	qDebug() << "GET:" << redis->get("key");
	qDebug() << "APPEND:" << redis->append("key", "\" World\"");
	qDebug() << "GET:" << redis->get("key");

	// Multi Set and Get example
	QMap<QString,QVariant> keypairs;
	keypairs["key1"] = QString("\"Hello\"");
	keypairs["key2"] = QString("\" world\"");
	qDebug() << "MSET:" << redis->mset(keypairs);
	qDebug() << "MGET:" << redis->mget("key1 key2 nonexisting");

	// Incr, incrby decr, decrby example.
	qDebug() << "SET:" << redis->set("count", "10");
	qDebug() << "INCR:" << redis->incr("count");
	qDebug() << "GET:" << redis->get("count");

	qDebug() << "INCRBY:" << redis->incrby("count",5);
	qDebug() << "GET:" << redis->get("count");

	qDebug() << "DECR:" << redis->decr("count");
	qDebug() << "GET:" << redis->get("count");

	qDebug() << "DECRBY:" << redis->decrby("count",5);
	qDebug() << "GET:" << redis->get("count");

	// SET and GET Range examples
	qDebug() << "SETRANGE:" << redis->setrange("key",6 ,"Redis");
	qDebug() << "GET:" << redis->get("key");

	qDebug() << "GETRANGE:" << redis->getrange("key",-5 ,-1);
	qDebug() << "GETRANGE:" << redis->getrange("key",0 ,4);
	qDebug() << "GETRANGE:" << redis->getrange("key",0 ,-1);
    */

    QString  KEY_RTDB_STATION_COUNT = "RTDB_STATION_COUNT";
    // Set and Get example
    qDebug() << "SET:" << redis->set(KEY_RTDB_STATION_COUNT, "3");
    qDebug() << "GET:" << redis->get(KEY_RTDB_STATION_COUNT);
	//Hashmap example
	int i=0;
	QString KEY_HASH_STATION = "HASH_RTDB_STATION_PARA";
    for(  i=0; i<3; i++)
    {
		QString sID,sName,sNodeID;
		sID = "StationID"+QString::number(i+1);
		sName = "StationName"+QString::number(i+1);
		sNodeID = "NodeID"+QString::number(i+1);
		qDebug() << "HSET:" << redis->hset(KEY_HASH_STATION,sID ,QString::number(i+1));
		qDebug() << "HSET:" << redis->hset(KEY_HASH_STATION,sName ,sName+QString::number(i+1));
		qDebug() << "HSET:" << redis->hset(KEY_HASH_STATION,sNodeID ,QString::number(i+1));
	
	}
	for(  i=0; i<3; i++)
	{
		QString KEY_HASH_STATION = "HASH_RTDB_STATION_PARA_"+QString::number(i+1);
		QMap<QString,QVariant> hashmap = redis->hgetall(KEY_HASH_STATION);
		QMapIterator<QString, QVariant> mi(hashmap);
		while (mi.hasNext())
		{
			mi.next();
			qDebug() << mi.key() << "=" << mi.value().toString();
		}
	}
	/*
	// Raw Command example
	reply = redis->command("GET key");
	qDebug() << "RAW:" << "("<< reply.type << ")" << reply.value.toString();

	redis->subscribe("notifications");

	redis->psubscribe("news.*");

	//reply = redis->command("SUBSCRIBE notifications");
	//qDebug() << "("<< reply.type << ")" << reply.value.toStringList();
	*/
}
void DrawView::creatAction()
{
	newAction = new QAction(tr("&New"),this);
	newAction->setIcon(QIcon(":/images/new.png"));
	newAction->setShortcut(QKeySequence::New);
	newAction->setStatusTip(tr("Create a new file"));
	connect(newAction,SIGNAL(triggered()),this,SLOT(newFile()));
	//
	openAction = new QAction(tr("&Open"),this);
	openAction->setIcon(QIcon(":/images/open.png"));
	openAction->setShortcut(QKeySequence::Open);
	openAction->setStatusTip(tr("Open a new file"));
	 connect(openAction, SIGNAL(triggered()), this, SLOT(open()));
	//
	saveAction = new QAction(tr("&Save"),this);
	saveAction->setIcon(QIcon(":/images/save.png"));
	saveAction->setShortcut(QKeySequence::Save);
	saveAction->setStatusTip(tr("Save file"));
	 connect(saveAction, SIGNAL(triggered()), this, SLOT(save()));
	//
	saveAsAction = new QAction(tr("Save &As"),this);
	saveAsAction->setIcon(QIcon(":/images/save.png"));
	//saveAsAction->setShortcut();
	saveAsAction->setStatusTip(tr("Save as file"));
	connect(saveAsAction, SIGNAL(triggered()), this, SLOT(saveAs()));
	for (int i = 0; i < MaxRecentFiles; ++i) {
		recentFileActions[i] = new QAction(this);
		recentFileActions[i]->setVisible(false);
		connect(recentFileActions[i], SIGNAL(triggered()),
			this, SLOT(openRecentFile()));
	}

	//
	exitAction = new QAction(tr("&Exit"),this);
	exitAction->setIcon(QIcon(":/images/new.png"));
	exitAction->setShortcut(tr("Ctrl+Q"));
	exitAction->setStatusTip(tr("Close Window"));
	connect(exitAction,SIGNAL(triggered()),this,SLOT(close()));
	//
	cutAction = new QAction(tr("&Cut"),this);
	cutAction->setIcon(QIcon(":/images/cut.png"));
	cutAction->setStatusTip(tr("Cut..."));
	//connect(cutAction,SIGNAL(triggered()),this,SLOT(cut()));
	//
	copyAction = new QAction(tr("&Copy"),this);
	copyAction->setIcon(QIcon(":/images/copy.png"));
	copyAction->setStatusTip(tr("Copy..."));
	//
	delAction = new QAction(tr("&Del"),this);
	delAction->setIcon(QIcon(":/images/g9.ico"));
	delAction->setStatusTip(tr("Delete..."));
    connect(delAction,SIGNAL(triggered()),this,SLOT(delSelect()));
	//
	pasteAction = new QAction(tr("&Paste"),this);
	pasteAction->setIcon(QIcon(":/images/paste.png"));
	pasteAction->setStatusTip(tr("Paste..."));
	//
	SelectAllAction = new QAction(tr("&SelectAll"),this);
	SelectAllAction->setIcon(QIcon(":/images/g9.ico"));
	SelectAllAction->setStatusTip(tr("Select all..."));
	connect(SelectAllAction,SIGNAL(triggered()),this,SLOT(SelectAll()));
	//
	setBackGroudColorAction = new QAction(tr("������ɫ"),this);
	setBackGroudColorAction->setStatusTip(tr("BackGroud Color"));
    connect(setBackGroudColorAction,SIGNAL(triggered()),this,SLOT(setBackgroundColor()));
	//
	drawArrowAction = new QAction(tr("��ͷ"),this);
	drawArrowAction->setIcon(QIcon(":/images/POINT13.ico"));
	drawArrowAction->setStatusTip(tr("��ͷ"));
	connect(drawArrowAction,SIGNAL(triggered()),this,SLOT(resetDraw()));
	//
	drawLineAction = new QAction(tr("Line"),this);
	drawLineAction->setIcon(QIcon(""));
	drawLineAction->setStatusTip(tr("����"));
	connect(drawLineAction,SIGNAL(triggered()),this,SLOT(drawLine()));
	drawCirleAction = new QAction(tr("Cirle"),this);
	drawCirleAction->setIcon(QIcon(""));
	drawCirleAction->setStatusTip(tr("��Բ"));
	connect(drawCirleAction,SIGNAL(triggered()),this,SLOT(drawCircle()));
	drawRectAction = new QAction(tr("Rect"),this);
	drawRectAction->setIcon(QIcon(""));
	drawRectAction->setStatusTip(tr("������"));
	connect(drawRectAction,SIGNAL(triggered()),this,SLOT(drawRect()));
	drawRoudRectAction = new QAction(tr("BoundRect"),this);
	drawRoudRectAction->setIcon(QIcon(""));
	drawRoudRectAction->setStatusTip(tr("Բ�Ǿ���"));
	connect(drawRoudRectAction,SIGNAL(triggered()),this,SLOT(drawRoudRect()));
    drawImageAction = new QAction(tr("ͼƬ"),this);
    drawImageAction->setIcon(QIcon(""));
    drawImageAction->setStatusTip(tr("ͼ���ļ�"));
    connect(drawImageAction,SIGNAL(triggered()),this,SLOT(drawImage()));
	////////////////////////////////////////////////
	rotateAction = new QAction(tr("ͼ����ת ˳ʱ"),this);
	rotateAction->setIcon(QIcon(""));
	rotateAction->setStatusTip(tr("ͼ����ת ˳ʱ"));
	connect(rotateAction,SIGNAL(triggered()),this,SLOT(rotateMap()));
    connect(rotateAction,SIGNAL(triggered()),this,SLOT(showDlg()));

}

void DrawView::createMenus()
{
	 fileMenu = menuBar()->addMenu(tr("&File"));
	 fileMenu->addAction(newAction);
	 fileMenu->addAction(openAction);
	 fileMenu->addAction(saveAction);
	 fileMenu->addAction(saveAsAction);
	 fileMenu->addSeparator();
	 fileMenu->addAction(exitAction);
	 menuBar()->addSeparator();
	 QMenu *menuEdit = menuBar()->addMenu(tr("&Edit"));
	 menuEdit->addAction(setBackGroudColorAction);
     menuEdit->addAction(rotateAction);
     menuEdit->addAction(SelectAllAction);
	 

}
void DrawView::createToolBars()
{
	fileToolBar = addToolBar(tr("&File"));
	fileToolBar->addAction(newAction);
	fileToolBar->addAction(openAction);
	fileToolBar->addAction(saveAction);
	editToolBar =addToolBar(tr("&Edit"));
	editToolBar->addAction(cutAction);
	editToolBar->addAction(copyAction);
	editToolBar->addAction(delAction);
	editToolBar->addAction(pasteAction);

	editToolBar->addSeparator();
	editToolBar =addToolBar(tr("&Draw"));
	editToolBar->addAction(drawArrowAction);
	editToolBar->addAction(drawLineAction);
	editToolBar->addAction(drawCirleAction);
	editToolBar->addAction(drawRectAction);
	editToolBar->addAction(drawRoudRectAction);
	editToolBar->addSeparator();
    editToolBar->addAction(drawImageAction);
    editToolBar->addSeparator();
}

void DrawView::createStatusBar()
{
	locationLabel = new QLabel(" W999 ");
	locationLabel->setAlignment(Qt::AlignHCenter);
	locationLabel->setMinimumSize(locationLabel->sizeHint());

	formulaLabel = new QLabel;
	formulaLabel->setIndent(3);

	statusBar()->addWidget(locationLabel);
	statusBar()->addWidget(formulaLabel, 1);
	
	connect(this, SIGNAL(mouseMoveEvent()),
		this, SLOT(updateStatusBar()));
    //connect(this,SIGNAL(wheelEvent()),this,SLOT(MouseWheel()));
	/*
	connect(spreadsheet, SIGNAL(modified()),
		this, SLOT(spreadsheetModified()));
	*/
	updateStatusBar();
}

void DrawView::wheelEvent(QWheelEvent *event)
{
    //m_pDrawMainView->wheelEvent(event);
	QSize screensize = m_pDrawMainView->GetScreenSize();
	 
    scrollArea->widget()->resize(screensize*m_pDrawMainView->GetScale());
	
}
void DrawView::mouseMoveEvent(QMouseEvent* event)
{
	 //updateStatusBar();
}

void DrawView::SetMousePostion(QPoint  Pt)
{
	QString sPoint;
	int x1,y1;
	x1 = Pt.x();
	y1 = Pt.y();
	sPoint = QString().sprintf("x=%d,y=%d",x1,y1);
	locationLabel->setText(sPoint); 
}

void DrawView::updateStatusBar()
{
	QString sPoint;
	QPoint Posion;
    QRect rect = this->geometry();
	sPoint = QString().sprintf("x=%d,y=%d",rect.x(),rect.y());
	locationLabel->setText(sPoint);
	//formulaLabel->setText(spreadsheet->currentFormula());
}

void DrawView::newFile()
{
	 if(okToContinue())
	 {
		 setCurrentFile("");
	 }
}


QString DrawView::strippedName(const QString &fullFileName)
{
	return QFileInfo(fullFileName).fileName();
}
void DrawView::setCurrentFile(const QString &fileName)
{
	m_curFile = fileName;
	setWindowModified(false);

	QString shownName = tr("Untitled");
	if (!m_curFile.isEmpty()) {
		shownName = strippedName(m_curFile);
		m_recentFiles.removeAll(m_curFile);
		m_recentFiles.prepend(m_curFile);
		updateRecentFileActions();
	}

	setWindowTitle(tr("%1[*] - %2").arg(shownName)
		.arg(tr("Spreadsheet")));
}
bool DrawView::okToContinue()
{
	if (isWindowModified()) {
		int r = QMessageBox::warning(this, tr("Spreadsheet"),
			tr("The document has been modified.\n"
			"Do you want to save your changes?"),
			QMessageBox::Yes | QMessageBox::No
			| QMessageBox::Cancel);
		if (r == QMessageBox::Yes) {
			return save();
		} else if (r == QMessageBox::Cancel) {
			return false;
		}
	}
	return true;
}

bool DrawView::loadFile(const QString &fileName)
{
	//if (!spreadsheet->readFile(fileName)) 
	{
		statusBar()->showMessage(tr("Loading canceled"), 2000);
		return false;
	}

	setCurrentFile(fileName);
	statusBar()->showMessage(tr("File loaded"), 2000);
	return true;
}

void DrawView::updateRecentFileActions()
{
	QMutableStringListIterator i(m_recentFiles);
	while (i.hasNext()) {
		if (!QFile::exists(i.next()))
			i.remove();
	}

	for (int j = 0; j < MaxRecentFiles; ++j) {
		if (j < m_recentFiles.count()) {
			QString text = tr("&%1 %2")
				.arg(j + 1)
				.arg(strippedName(m_recentFiles[j]));
			recentFileActions[j]->setText(text);
			recentFileActions[j]->setData(m_recentFiles[j]);
			recentFileActions[j]->setVisible(true);
		} else {
			recentFileActions[j]->setVisible(false);
		}
	}
	//separatorAction->setVisible(!m_recentFiles.isEmpty());
}

void DrawView::open()
{
	
	if (okToContinue()) {
// 		QString fileName = QFileDialog::getOpenFileName(this,
// 			tr("Open Spreadsheet"), ".",
// 			tr("Spreadsheet files (*.sp)"));
		QString fileName  =QFileDialog::getOpenFileName(this,tr("Open File"),QString(),tr("Text Files(*.map);;Jxt Files(*.jxt)"));
		if (!fileName.isEmpty())
			//loadFile(fileName);
			m_pDrawMainView->open(fileName);
	}
	
}

bool DrawView::save()
{
	if(m_curFile.isEmpty())
	{
		return saveAs();
	}
	else{
		m_pDrawMainView->save(m_curFile);
		if (m_curFile.isEmpty()) {
			return saveAs();
		} else 
		{
			return saveFile(m_curFile);
		}
	}

}

bool DrawView::saveAs()
{
	 QString sFileName;
	 m_curFile =sFileName =QFileDialog::getSaveFileName(this,tr("Save File"),QString(),tr("Text Files(*.map);;Jxt Files(*.jxt)"));
	if (sFileName.isEmpty())
		return false;
    saveFile(sFileName);
	return m_pDrawMainView->save(m_curFile);
	  
}

bool DrawView::saveFile(const QString &fileName)
{
	/*
	if (!spreadsheet->writeFile(fileName)) {
		statusBar()->showMessage(tr("Saving canceled"), 2000);
		return false;
	}
	*/
	setCurrentFile(fileName);
	statusBar()->showMessage(tr("File saved"), 2000);
	 
	return true;
}


void DrawView::closeEvent(QCloseEvent *event)
{
	if (okToContinue()) {
		writeSettings();
		event->accept();
	} else {
		event->ignore();
	}
}

void DrawView::writeSettings()
{
	QSettings settings("Software Inc.", "Spreadsheet");

	//settings.setValue("geometry", saveGeometry());
	settings.setValue("recentFiles", m_recentFiles);
	//settings.setValue("showGrid", showGridAction->isChecked());
	//settings.setValue("autoRecalc", autoRecalcAction->isChecked());
}

void DrawView::SelectAll()
{
	m_pDrawMainView->SelectAll();
}

void DrawView::delSelect()
{
    m_pDrawMainView->DeleteSelect();
}

void DrawView::rotateMap()
{
	 m_pDrawMainView->rotateMap();
}
void DrawView::setBackgroundColor()
{
    QColor Rgb = QColorDialog::getColor(Qt::black);
	 m_pDrawMainView->setBackgroundColor(Rgb);
}

void DrawView::resetDraw()
{
	 m_pDrawMainView->SetDrawType(NO_DRAW);
}

void DrawView::drawLine()
{
	 m_pDrawMainView->SetDrawType(CHART_LINE);
}

void DrawView::drawCircle()
{
    m_pDrawMainView->SetDrawType(CHART_ARC);
}

void DrawView::drawRect()
{
	 m_pDrawMainView->SetDrawType(CHART_RECT);
}
void DrawView::drawRoudRect()
{
	m_pDrawMainView->SetDrawType(CHART_BOUNDRECT);
}
void DrawView::drawImage()
{
    m_pDrawMainView->SetDrawType(CHART_BITMAP);
}
void DrawView::showDlg()
{
    myqttestDlg *dlg = new myqttestDlg(this);
    dlg->exec();
	if(dlg!=NULL) delete dlg;
	dlg = NULL;
	 

}
