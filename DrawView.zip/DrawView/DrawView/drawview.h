#ifndef DRAWVIEW_H
#define DRAWVIEW_H

#include <QtGui/QMainWindow>
#include "ui_drawview.h"
 #include"ChartPara.h"
#include <QScrollArea>

#include <QMap>
#include "qRedis.h"
#include "qmysql.h"

class QAction;
class QLabel;
class QDrawMainView;
class DrawView : public QMainWindow
{
	Q_OBJECT
public:
	QDrawMainView *m_pDrawMainView;
private:
    QScrollArea *scrollArea;
	//
	 QStringList m_recentFiles;
	QString m_curFile;
	QAction *newAction;
	QAction *openAction;
	QAction *saveAction;
	QAction *saveAsAction;
	QAction *exitAction;
	enum { MaxRecentFiles = 5 };
	QAction *recentFileActions[MaxRecentFiles];
	//
	QAction *rotateAction;
	QAction *setBackGroudColorAction;
	QAction *cutAction;
	QAction *copyAction;
	QAction *delAction;
	QAction *pasteAction;
	QAction *SelectAllAction;
	//
	QAction *findAction;
	//��ͼ����
	QAction *drawArrowAction;//��ͷ
	QAction *drawLineAction;
	QAction *drawCirleAction;
	QAction *drawRectAction;
	QAction *drawRoudRectAction;
    QAction *drawImageAction;
	//
	QMenu *fileMenu;
	QMenu *editMenu;
	//
	QToolBar *fileToolBar;
	QToolBar *editToolBar;

	QLabel *locationLabel;
	QLabel *formulaLabel;
	 
private:
	
	bool loadFile(const QString &fileName);
	void writeSettings();
	bool saveFile(const QString &fileName);
	
	void setCurrentFile(const QString &fileName);
	void creatAction();
	void createMenus();
	void createToolBars();
	void createStatusBar();
	void updateStatusBar();
private slots:
		void newFile();
		void open();
		bool saveAs();
		bool save();
		//
		void SelectAll();//ȫѡ
		void delSelect();//ɾ��ѡ�е�Ԫ��
        void showDlg();//��ʾ�Ի���
		void rotateMap();
        void setBackgroundColor();
		void resetDraw();
        void drawLine();
		void drawCircle();
		void drawRect();
		void drawRoudRect();
        void drawImage();
		void mouseMoveEvent(QMouseEvent* event);
		// �Ŵ�/��С
		void wheelEvent(QWheelEvent *event);
      
public:
        void startMySql();
        void startRedis();
        void SetMousePostion(QPoint  Pt);
        void updateRecentFileActions();
        QString strippedName(const QString &fullFileName);
        bool okToContinue();
        DrawView(QWidget *parent = 0, Qt::WFlags flags = 0);
        ~DrawView();
protected:
   void closeEvent(QCloseEvent *event);
private:
    Ui::DrawViewClass ui;
};

#endif // DRAWVIEW_H
