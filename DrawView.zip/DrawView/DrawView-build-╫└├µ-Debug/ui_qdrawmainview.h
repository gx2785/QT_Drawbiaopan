/********************************************************************************
** Form generated from reading UI file 'qdrawmainview.ui'
**
** Created: Mon Feb 26 13:25:22 2018
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QDRAWMAINVIEW_H
#define UI_QDRAWMAINVIEW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QDrawMainView
{
public:

    void setupUi(QWidget *QDrawMainView)
    {
        if (QDrawMainView->objectName().isEmpty())
            QDrawMainView->setObjectName(QString::fromUtf8("QDrawMainView"));
        QDrawMainView->resize(1163, 753);

        retranslateUi(QDrawMainView);

        QMetaObject::connectSlotsByName(QDrawMainView);
    } // setupUi

    void retranslateUi(QWidget *QDrawMainView)
    {
        QDrawMainView->setWindowTitle(QApplication::translate("QDrawMainView", "QDrawMainView", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class QDrawMainView: public Ui_QDrawMainView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QDRAWMAINVIEW_H
