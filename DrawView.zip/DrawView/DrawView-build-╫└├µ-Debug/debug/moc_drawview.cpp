/****************************************************************************
** Meta object code from reading C++ file 'drawview.h'
**
** Created: Wed May 9 09:37:10 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../DrawView/drawview.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'drawview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_DrawView[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x08,
      20,    9,    9,    9, 0x08,
      32,    9,   27,    9, 0x08,
      41,    9,   27,    9, 0x08,
      48,    9,    9,    9, 0x08,
      60,    9,    9,    9, 0x08,
      72,    9,    9,    9, 0x08,
      82,    9,    9,    9, 0x08,
      94,    9,    9,    9, 0x08,
     115,    9,    9,    9, 0x08,
     127,    9,    9,    9, 0x08,
     138,    9,    9,    9, 0x08,
     151,    9,    9,    9, 0x08,
     162,    9,    9,    9, 0x08,
     177,    9,    9,    9, 0x08,
     195,  189,    9,    9, 0x08,
     224,  189,    9,    9, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_DrawView[] = {
    "DrawView\0\0newFile()\0open()\0bool\0"
    "saveAs()\0save()\0SelectAll()\0delSelect()\0"
    "showDlg()\0rotateMap()\0setBackgroundColor()\0"
    "resetDraw()\0drawLine()\0drawCircle()\0"
    "drawRect()\0drawRoudRect()\0drawImage()\0"
    "event\0mouseMoveEvent(QMouseEvent*)\0"
    "wheelEvent(QWheelEvent*)\0"
};

void DrawView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        DrawView *_t = static_cast<DrawView *>(_o);
        switch (_id) {
        case 0: _t->newFile(); break;
        case 1: _t->open(); break;
        case 2: { bool _r = _t->saveAs();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 3: { bool _r = _t->save();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 4: _t->SelectAll(); break;
        case 5: _t->delSelect(); break;
        case 6: _t->showDlg(); break;
        case 7: _t->rotateMap(); break;
        case 8: _t->setBackgroundColor(); break;
        case 9: _t->resetDraw(); break;
        case 10: _t->drawLine(); break;
        case 11: _t->drawCircle(); break;
        case 12: _t->drawRect(); break;
        case 13: _t->drawRoudRect(); break;
        case 14: _t->drawImage(); break;
        case 15: _t->mouseMoveEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 16: _t->wheelEvent((*reinterpret_cast< QWheelEvent*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData DrawView::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject DrawView::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_DrawView,
      qt_meta_data_DrawView, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &DrawView::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *DrawView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *DrawView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DrawView))
        return static_cast<void*>(const_cast< DrawView*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int DrawView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
