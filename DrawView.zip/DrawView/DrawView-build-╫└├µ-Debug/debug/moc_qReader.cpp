/****************************************************************************
** Meta object code from reading C++ file 'qReader.h'
**
** Created: Mon Feb 26 13:25:34 2018
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../DrawView/qReader.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qReader.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Reader[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
       8,    7,    7,    7, 0x05,
      27,    7,    7,    7, 0x05,
      39,    7,    7,    7, 0x05,
      54,    7,    7,    7, 0x05,

 // slots: signature, parameters, type, tag, flags
      90,    7,    7,    7, 0x0a,
     108,    7,    7,    7, 0x0a,
     133,    7,    7,    7, 0x0a,
     151,    7,    7,    7, 0x0a,
     193,    7,    7,    7, 0x0a,
     211,    7,    7,    7, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Reader[] = {
    "Reader\0\0response(QVariant)\0connected()\0"
    "disconnected()\0error(QAbstractSocket::SocketError)\0"
    "socketConnected()\0socketConnectionClosed()\0"
    "socketReadyRead()\0"
    "socketError(QAbstractSocket::SocketError)\0"
    "sendData(QString)\0readLine(QString)\0"
};

void Reader::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Reader *_t = static_cast<Reader *>(_o);
        switch (_id) {
        case 0: _t->response((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 1: _t->connected(); break;
        case 2: _t->disconnected(); break;
        case 3: _t->error((*reinterpret_cast< QAbstractSocket::SocketError(*)>(_a[1]))); break;
        case 4: _t->socketConnected(); break;
        case 5: _t->socketConnectionClosed(); break;
        case 6: _t->socketReadyRead(); break;
        case 7: _t->socketError((*reinterpret_cast< QAbstractSocket::SocketError(*)>(_a[1]))); break;
        case 8: _t->sendData((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->readLine((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Reader::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Reader::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Reader,
      qt_meta_data_Reader, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Reader::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Reader::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Reader::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Reader))
        return static_cast<void*>(const_cast< Reader*>(this));
    return QObject::qt_metacast(_clname);
}

int Reader::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void Reader::response(QVariant _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Reader::connected()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void Reader::disconnected()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void Reader::error(QAbstractSocket::SocketError _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
